﻿namespace school_management_system
{
    partial class frm_Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Main_Menu));
            this.Master_entryMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ClassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SectionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eventToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feesDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BooksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transportationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BooksuppliersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feeEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schoolEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.busHoldersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.busFeePaymentToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.feePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeSalaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelFeesPaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipPaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentRecordToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelersToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.busHoldersToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feePaymentRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeePaymentRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelFeePaymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.busFeePaymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipPaymentRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookIssueRToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bookissueStaffsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bookReturnstudentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookReturnStaffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eventRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookEntryRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hostlersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.busHoldersToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.studentProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendanceToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.feesDetailsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.internalMarksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.salaryPaymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.salarySlipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feePaymentToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.feeReceiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipPaymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelFeePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersTransactionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.busFeePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipPaymentReceiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.busFeePaymentReceiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelFeePaymentReceiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.transportationChargesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subjectInfoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.EventtoolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.calculatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notepadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taskManagerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wordpadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataBaseBackUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreDataBaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.masterEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SchooltoolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.classToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departmentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.eventToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.feeEntryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.transportationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eventToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subjectEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marksEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.examsEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginDetailsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.loginDetailsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.profileEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profileEntryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.profileEntryToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelersToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.busCardHoldersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ClassFeePaymentToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.busFeePaymentToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelFeePaymentToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipPaymentToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeSalaryPaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookIssueToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bookReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelersToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.busHoldersToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.employeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.claToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.busFeePaymentToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipPaymentToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelFeePaymentToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.BookstoolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.bookIssueStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookIssueStaffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookReturnStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookReturnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eventRecordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.subjectRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marksRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.busHoldersToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelersToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.classFeePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salaryPaymentToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.busFeePaymentReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.studentMarksReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculatorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.notepadToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.taskManagerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mSWordToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.wordpadToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseBackupToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseRecoveryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.logsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserType = new System.Windows.Forms.ToolStripStatusLabel();
            this.User = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Time = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.bookIssueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BookretunToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.salaryPaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feePaymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelFeePaymentToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseBakupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseRecoveryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logouToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.salaryPaymentToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.feePaymentToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.hostelFeePaymentToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.busFeePaymentToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.scholarshipPaymentToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseBackupToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseRecoveryToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.logsToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip3.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Master_entryMenu
            // 
            this.Master_entryMenu.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Master_entryMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ClassToolStripMenuItem,
            this.SectionsToolStripMenuItem,
            this.departmentToolStripMenuItem,
            this.eventToolStripMenuItem,
            this.feesDetailsToolStripMenuItem,
            this.hostelToolStripMenuItem,
            this.scholarshipToolStripMenuItem,
            this.BooksToolStripMenuItem,
            this.transportationToolStripMenuItem,
            this.BooksuppliersToolStripMenuItem,
            this.feeEntryToolStripMenuItem,
            this.schoolEntryToolStripMenuItem});
            this.Master_entryMenu.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Master_entryMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Master_entryMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.Master_entryMenu.Name = "Master_entryMenu";
            this.Master_entryMenu.Size = new System.Drawing.Size(97, 22);
            this.Master_entryMenu.Text = "&Master Entry";
            // 
            // ClassToolStripMenuItem
            // 
            this.ClassToolStripMenuItem.Name = "ClassToolStripMenuItem";
            this.ClassToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // SectionsToolStripMenuItem
            // 
            this.SectionsToolStripMenuItem.Name = "SectionsToolStripMenuItem";
            this.SectionsToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // departmentToolStripMenuItem
            // 
            this.departmentToolStripMenuItem.Name = "departmentToolStripMenuItem";
            this.departmentToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // eventToolStripMenuItem
            // 
            this.eventToolStripMenuItem.Name = "eventToolStripMenuItem";
            this.eventToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // feesDetailsToolStripMenuItem
            // 
            this.feesDetailsToolStripMenuItem.Name = "feesDetailsToolStripMenuItem";
            this.feesDetailsToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // hostelToolStripMenuItem
            // 
            this.hostelToolStripMenuItem.Name = "hostelToolStripMenuItem";
            this.hostelToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // scholarshipToolStripMenuItem
            // 
            this.scholarshipToolStripMenuItem.Name = "scholarshipToolStripMenuItem";
            this.scholarshipToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // BooksToolStripMenuItem
            // 
            this.BooksToolStripMenuItem.Name = "BooksToolStripMenuItem";
            this.BooksToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // transportationToolStripMenuItem
            // 
            this.transportationToolStripMenuItem.Name = "transportationToolStripMenuItem";
            this.transportationToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // BooksuppliersToolStripMenuItem
            // 
            this.BooksuppliersToolStripMenuItem.Name = "BooksuppliersToolStripMenuItem";
            this.BooksuppliersToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // feeEntryToolStripMenuItem
            // 
            this.feeEntryToolStripMenuItem.Name = "feeEntryToolStripMenuItem";
            this.feeEntryToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // schoolEntryToolStripMenuItem
            // 
            this.schoolEntryToolStripMenuItem.Name = "schoolEntryToolStripMenuItem";
            this.schoolEntryToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // usersToolStripMenuItem
            // 
            this.usersToolStripMenuItem.BackColor = System.Drawing.Color.DarkSlateGray;
            this.usersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginDetailsToolStripMenuItem,
            this.registrationToolStripMenuItem});
            this.usersToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usersToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            this.usersToolStripMenuItem.Size = new System.Drawing.Size(54, 22);
            this.usersToolStripMenuItem.Text = "&Users";
            // 
            // loginDetailsToolStripMenuItem
            // 
            this.loginDetailsToolStripMenuItem.Name = "loginDetailsToolStripMenuItem";
            this.loginDetailsToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // registrationToolStripMenuItem
            // 
            this.registrationToolStripMenuItem.Name = "registrationToolStripMenuItem";
            this.registrationToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // employeeToolStripMenuItem
            // 
            this.employeeToolStripMenuItem.Name = "employeeToolStripMenuItem";
            this.employeeToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // employeeProfileToolStripMenuItem
            // 
            this.employeeProfileToolStripMenuItem.Name = "employeeProfileToolStripMenuItem";
            this.employeeProfileToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // studentDetailsToolStripMenuItem
            // 
            this.studentDetailsToolStripMenuItem.Name = "studentDetailsToolStripMenuItem";
            this.studentDetailsToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // hostelersToolStripMenuItem
            // 
            this.hostelersToolStripMenuItem.Name = "hostelersToolStripMenuItem";
            this.hostelersToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // busHoldersToolStripMenuItem
            // 
            this.busHoldersToolStripMenuItem.Name = "busHoldersToolStripMenuItem";
            this.busHoldersToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // transactionToolStripMenuItem
            // 
            this.transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            this.transactionToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // busFeePaymentToolStripMenuItem2
            // 
            this.busFeePaymentToolStripMenuItem2.Name = "busFeePaymentToolStripMenuItem2";
            this.busFeePaymentToolStripMenuItem2.Size = new System.Drawing.Size(32, 19);
            // 
            // feePaymentToolStripMenuItem
            // 
            this.feePaymentToolStripMenuItem.Name = "feePaymentToolStripMenuItem";
            this.feePaymentToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // employeeSalaryToolStripMenuItem
            // 
            this.employeeSalaryToolStripMenuItem.Name = "employeeSalaryToolStripMenuItem";
            this.employeeSalaryToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // hostelFeesPaymentToolStripMenuItem
            // 
            this.hostelFeesPaymentToolStripMenuItem.Name = "hostelFeesPaymentToolStripMenuItem";
            this.hostelFeesPaymentToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // scholarshipPaymentToolStripMenuItem
            // 
            this.scholarshipPaymentToolStripMenuItem.Name = "scholarshipPaymentToolStripMenuItem";
            this.scholarshipPaymentToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.BackColor = System.Drawing.Color.DarkSlateGray;
            this.searchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentRecordToolStripMenuItem1,
            this.hostelersToolStripMenuItem1,
            this.busHoldersToolStripMenuItem1,
            this.employeeRecordToolStripMenuItem,
            this.feePaymentRecordToolStripMenuItem,
            this.employeePaymentRecordToolStripMenuItem,
            this.hostelFeePaymentToolStripMenuItem1,
            this.busFeePaymentToolStripMenuItem1,
            this.scholarshipPaymentRecordToolStripMenuItem,
            this.bookIssueRToolStripMenuItem1,
            this.bookissueStaffsToolStripMenuItem1,
            this.bookReturnstudentsToolStripMenuItem,
            this.bookReturnStaffToolStripMenuItem,
            this.eventRecordsToolStripMenuItem,
            this.bookEntryRecordsToolStripMenuItem});
            this.searchToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(69, 22);
            this.searchToolStripMenuItem.Text = "Records";
            // 
            // studentRecordToolStripMenuItem1
            // 
            this.studentRecordToolStripMenuItem1.Name = "studentRecordToolStripMenuItem1";
            this.studentRecordToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.studentRecordToolStripMenuItem1.Text = "Students";
            // 
            // hostelersToolStripMenuItem1
            // 
            this.hostelersToolStripMenuItem1.Name = "hostelersToolStripMenuItem1";
            this.hostelersToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.hostelersToolStripMenuItem1.Text = "Hostelers";
            // 
            // busHoldersToolStripMenuItem1
            // 
            this.busHoldersToolStripMenuItem1.Name = "busHoldersToolStripMenuItem1";
            this.busHoldersToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.busHoldersToolStripMenuItem1.Text = "Bus Holders";
            // 
            // employeeRecordToolStripMenuItem
            // 
            this.employeeRecordToolStripMenuItem.Name = "employeeRecordToolStripMenuItem";
            this.employeeRecordToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.employeeRecordToolStripMenuItem.Text = "Employees";
            // 
            // feePaymentRecordToolStripMenuItem
            // 
            this.feePaymentRecordToolStripMenuItem.Name = "feePaymentRecordToolStripMenuItem";
            this.feePaymentRecordToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.feePaymentRecordToolStripMenuItem.Text = "Class Fee Payment";
            // 
            // employeePaymentRecordToolStripMenuItem
            // 
            this.employeePaymentRecordToolStripMenuItem.Name = "employeePaymentRecordToolStripMenuItem";
            this.employeePaymentRecordToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.employeePaymentRecordToolStripMenuItem.Text = "Employee Payment";
            // 
            // hostelFeePaymentToolStripMenuItem1
            // 
            this.hostelFeePaymentToolStripMenuItem1.Name = "hostelFeePaymentToolStripMenuItem1";
            this.hostelFeePaymentToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.hostelFeePaymentToolStripMenuItem1.Text = "Hostel Fee Payment";
            // 
            // busFeePaymentToolStripMenuItem1
            // 
            this.busFeePaymentToolStripMenuItem1.Name = "busFeePaymentToolStripMenuItem1";
            this.busFeePaymentToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.busFeePaymentToolStripMenuItem1.Text = "Bus Fee Payment";
            // 
            // scholarshipPaymentRecordToolStripMenuItem
            // 
            this.scholarshipPaymentRecordToolStripMenuItem.Name = "scholarshipPaymentRecordToolStripMenuItem";
            this.scholarshipPaymentRecordToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.scholarshipPaymentRecordToolStripMenuItem.Text = "Scholarship Payment";
            // 
            // bookIssueRToolStripMenuItem1
            // 
            this.bookIssueRToolStripMenuItem1.Name = "bookIssueRToolStripMenuItem1";
            this.bookIssueRToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.bookIssueRToolStripMenuItem1.Text = "Book Issue Student";
            // 
            // bookissueStaffsToolStripMenuItem1
            // 
            this.bookissueStaffsToolStripMenuItem1.Name = "bookissueStaffsToolStripMenuItem1";
            this.bookissueStaffsToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.bookissueStaffsToolStripMenuItem1.Text = "BookIssueStaff";
            // 
            // bookReturnstudentsToolStripMenuItem
            // 
            this.bookReturnstudentsToolStripMenuItem.Name = "bookReturnstudentsToolStripMenuItem";
            this.bookReturnstudentsToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.bookReturnstudentsToolStripMenuItem.Text = "BookReturnStudent";
            // 
            // bookReturnStaffToolStripMenuItem
            // 
            this.bookReturnStaffToolStripMenuItem.Name = "bookReturnStaffToolStripMenuItem";
            this.bookReturnStaffToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.bookReturnStaffToolStripMenuItem.Text = "BookReturnStaff";
            // 
            // eventRecordsToolStripMenuItem
            // 
            this.eventRecordsToolStripMenuItem.Name = "eventRecordsToolStripMenuItem";
            this.eventRecordsToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            // 
            // bookEntryRecordsToolStripMenuItem
            // 
            this.bookEntryRecordsToolStripMenuItem.Name = "bookEntryRecordsToolStripMenuItem";
            this.bookEntryRecordsToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.bookEntryRecordsToolStripMenuItem.Text = "Book Entry Records";
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.BackColor = System.Drawing.Color.DarkSlateGray;
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentsRegistrationToolStripMenuItem,
            this.studentsToolStripMenuItem,
            this.hostlersToolStripMenuItem,
            this.busHoldersToolStripMenuItem2,
            this.studentProfileToolStripMenuItem,
            this.attendanceToolStripMenuItem2,
            this.feesDetailsToolStripMenuItem1,
            this.internalMarksToolStripMenuItem,
            this.employeeToolStripMenuItem2,
            this.salaryPaymentToolStripMenuItem1,
            this.salarySlipToolStripMenuItem,
            this.feePaymentToolStripMenuItem2,
            this.feeReceiptToolStripMenuItem,
            this.scholarshipPaymentToolStripMenuItem1,
            this.hostelFeePaymentToolStripMenuItem,
            this.othersTransactionToolStripMenuItem1,
            this.busFeePaymentToolStripMenuItem,
            this.scholarshipPaymentReceiptToolStripMenuItem,
            this.busFeePaymentReceiptToolStripMenuItem,
            this.hostelFeePaymentReceiptToolStripMenuItem,
            this.registrationToolStripMenuItem1,
            this.transportationChargesToolStripMenuItem,
            this.subjectInfoToolStripMenuItem1,
            this.EventtoolStripMenuItem1});
            this.reportToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            this.reportToolStripMenuItem.Text = "Reports";
            // 
            // studentsRegistrationToolStripMenuItem
            // 
            this.studentsRegistrationToolStripMenuItem.Name = "studentsRegistrationToolStripMenuItem";
            this.studentsRegistrationToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.studentsRegistrationToolStripMenuItem.Text = "Students Registration";
            // 
            // studentsToolStripMenuItem
            // 
            this.studentsToolStripMenuItem.Name = "studentsToolStripMenuItem";
            this.studentsToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.studentsToolStripMenuItem.Text = "Students ";
            // 
            // hostlersToolStripMenuItem
            // 
            this.hostlersToolStripMenuItem.Name = "hostlersToolStripMenuItem";
            this.hostlersToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.hostlersToolStripMenuItem.Text = "Hostelers";
            // 
            // busHoldersToolStripMenuItem2
            // 
            this.busHoldersToolStripMenuItem2.Name = "busHoldersToolStripMenuItem2";
            this.busHoldersToolStripMenuItem2.Size = new System.Drawing.Size(252, 22);
            this.busHoldersToolStripMenuItem2.Text = "Bus Holders";
            // 
            // studentProfileToolStripMenuItem
            // 
            this.studentProfileToolStripMenuItem.Name = "studentProfileToolStripMenuItem";
            this.studentProfileToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.studentProfileToolStripMenuItem.Text = "Student Profile";
            // 
            // attendanceToolStripMenuItem2
            // 
            this.attendanceToolStripMenuItem2.Name = "attendanceToolStripMenuItem2";
            this.attendanceToolStripMenuItem2.Size = new System.Drawing.Size(252, 22);
            this.attendanceToolStripMenuItem2.Text = "Students Attendance";
            // 
            // feesDetailsToolStripMenuItem1
            // 
            this.feesDetailsToolStripMenuItem1.Name = "feesDetailsToolStripMenuItem1";
            this.feesDetailsToolStripMenuItem1.Size = new System.Drawing.Size(252, 22);
            this.feesDetailsToolStripMenuItem1.Text = "Fees Details";
            // 
            // internalMarksToolStripMenuItem
            // 
            this.internalMarksToolStripMenuItem.Name = "internalMarksToolStripMenuItem";
            this.internalMarksToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.internalMarksToolStripMenuItem.Text = "Internal Marks";
            // 
            // employeeToolStripMenuItem2
            // 
            this.employeeToolStripMenuItem2.Name = "employeeToolStripMenuItem2";
            this.employeeToolStripMenuItem2.Size = new System.Drawing.Size(252, 22);
            this.employeeToolStripMenuItem2.Text = "Employees";
            // 
            // salaryPaymentToolStripMenuItem1
            // 
            this.salaryPaymentToolStripMenuItem1.Name = "salaryPaymentToolStripMenuItem1";
            this.salaryPaymentToolStripMenuItem1.Size = new System.Drawing.Size(252, 22);
            this.salaryPaymentToolStripMenuItem1.Text = "Salary Payment";
            // 
            // salarySlipToolStripMenuItem
            // 
            this.salarySlipToolStripMenuItem.Name = "salarySlipToolStripMenuItem";
            this.salarySlipToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.salarySlipToolStripMenuItem.Text = "Salary Slip";
            // 
            // feePaymentToolStripMenuItem2
            // 
            this.feePaymentToolStripMenuItem2.Name = "feePaymentToolStripMenuItem2";
            this.feePaymentToolStripMenuItem2.Size = new System.Drawing.Size(252, 22);
            this.feePaymentToolStripMenuItem2.Text = "Course Fee Payment";
            // 
            // feeReceiptToolStripMenuItem
            // 
            this.feeReceiptToolStripMenuItem.Name = "feeReceiptToolStripMenuItem";
            this.feeReceiptToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.feeReceiptToolStripMenuItem.Text = "Course Fee Payment Receipt";
            // 
            // scholarshipPaymentToolStripMenuItem1
            // 
            this.scholarshipPaymentToolStripMenuItem1.Name = "scholarshipPaymentToolStripMenuItem1";
            this.scholarshipPaymentToolStripMenuItem1.Size = new System.Drawing.Size(252, 22);
            this.scholarshipPaymentToolStripMenuItem1.Text = "Scholarship Payment";
            // 
            // hostelFeePaymentToolStripMenuItem
            // 
            this.hostelFeePaymentToolStripMenuItem.Name = "hostelFeePaymentToolStripMenuItem";
            this.hostelFeePaymentToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.hostelFeePaymentToolStripMenuItem.Text = "Hostel Fee Payment";
            // 
            // othersTransactionToolStripMenuItem1
            // 
            this.othersTransactionToolStripMenuItem1.Name = "othersTransactionToolStripMenuItem1";
            this.othersTransactionToolStripMenuItem1.Size = new System.Drawing.Size(252, 22);
            this.othersTransactionToolStripMenuItem1.Text = "Others Transaction";
            // 
            // busFeePaymentToolStripMenuItem
            // 
            this.busFeePaymentToolStripMenuItem.Name = "busFeePaymentToolStripMenuItem";
            this.busFeePaymentToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.busFeePaymentToolStripMenuItem.Text = "Bus Fee Payment";
            // 
            // scholarshipPaymentReceiptToolStripMenuItem
            // 
            this.scholarshipPaymentReceiptToolStripMenuItem.Name = "scholarshipPaymentReceiptToolStripMenuItem";
            this.scholarshipPaymentReceiptToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.scholarshipPaymentReceiptToolStripMenuItem.Text = "Scholarship Payment Receipt";
            // 
            // busFeePaymentReceiptToolStripMenuItem
            // 
            this.busFeePaymentReceiptToolStripMenuItem.Name = "busFeePaymentReceiptToolStripMenuItem";
            this.busFeePaymentReceiptToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.busFeePaymentReceiptToolStripMenuItem.Text = "Bus Fee Payment Receipt";
            // 
            // hostelFeePaymentReceiptToolStripMenuItem
            // 
            this.hostelFeePaymentReceiptToolStripMenuItem.Name = "hostelFeePaymentReceiptToolStripMenuItem";
            this.hostelFeePaymentReceiptToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.hostelFeePaymentReceiptToolStripMenuItem.Text = "Hostel Fee Payment Receipt";
            // 
            // registrationToolStripMenuItem1
            // 
            this.registrationToolStripMenuItem1.Name = "registrationToolStripMenuItem1";
            this.registrationToolStripMenuItem1.Size = new System.Drawing.Size(252, 22);
            this.registrationToolStripMenuItem1.Text = "Users Registration";
            // 
            // transportationChargesToolStripMenuItem
            // 
            this.transportationChargesToolStripMenuItem.Name = "transportationChargesToolStripMenuItem";
            this.transportationChargesToolStripMenuItem.Size = new System.Drawing.Size(252, 22);
            this.transportationChargesToolStripMenuItem.Text = "Transportation Charges";
            // 
            // subjectInfoToolStripMenuItem1
            // 
            this.subjectInfoToolStripMenuItem1.Name = "subjectInfoToolStripMenuItem1";
            this.subjectInfoToolStripMenuItem1.Size = new System.Drawing.Size(252, 22);
            this.subjectInfoToolStripMenuItem1.Text = "Subject Info";
            // 
            // EventtoolStripMenuItem1
            // 
            this.EventtoolStripMenuItem1.Name = "EventtoolStripMenuItem1";
            this.EventtoolStripMenuItem1.Size = new System.Drawing.Size(252, 22);
            this.EventtoolStripMenuItem1.Text = "Events";
            // 
            // toolsMenu
            // 
            this.toolsMenu.BackColor = System.Drawing.Color.DarkSlateGray;
            this.toolsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculatorToolStripMenuItem,
            this.notepadToolStripMenuItem,
            this.taskManagerToolStripMenuItem,
            this.mSWordToolStripMenuItem,
            this.wordpadToolStripMenuItem});
            this.toolsMenu.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolsMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.toolsMenu.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolsMenu.Name = "toolsMenu";
            this.toolsMenu.Size = new System.Drawing.Size(55, 22);
            this.toolsMenu.Text = "&Tools";
            // 
            // calculatorToolStripMenuItem
            // 
            this.calculatorToolStripMenuItem.Image = global::school_management_system.Properties.Resources.calc;
            this.calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            this.calculatorToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.calculatorToolStripMenuItem.Text = "Calculator";
            // 
            // notepadToolStripMenuItem
            // 
            this.notepadToolStripMenuItem.Image = global::school_management_system.Properties.Resources.Notepad11;
            this.notepadToolStripMenuItem.Name = "notepadToolStripMenuItem";
            this.notepadToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.notepadToolStripMenuItem.Text = "Notepad";
            // 
            // taskManagerToolStripMenuItem
            // 
            this.taskManagerToolStripMenuItem.Image = global::school_management_system.Properties.Resources.task_manager1;
            this.taskManagerToolStripMenuItem.Name = "taskManagerToolStripMenuItem";
            this.taskManagerToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.taskManagerToolStripMenuItem.Text = "Task Manager";
            // 
            // mSWordToolStripMenuItem
            // 
            this.mSWordToolStripMenuItem.Image = global::school_management_system.Properties.Resources.MS_Word_2_icon1;
            this.mSWordToolStripMenuItem.Name = "mSWordToolStripMenuItem";
            this.mSWordToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.mSWordToolStripMenuItem.Text = "MS Word";
            // 
            // wordpadToolStripMenuItem
            // 
            this.wordpadToolStripMenuItem.Image = global::school_management_system.Properties.Resources.Wordpad_icon__Windows_7_1;
            this.wordpadToolStripMenuItem.Name = "wordpadToolStripMenuItem";
            this.wordpadToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.wordpadToolStripMenuItem.Text = "Wordpad";
            // 
            // dataBaseBackUpToolStripMenuItem
            // 
            this.dataBaseBackUpToolStripMenuItem.BackColor = System.Drawing.Color.DarkSlateGray;
            this.dataBaseBackUpToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataBaseBackUpToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataBaseBackUpToolStripMenuItem.Name = "dataBaseBackUpToolStripMenuItem";
            this.dataBaseBackUpToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.dataBaseBackUpToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.dataBaseBackUpToolStripMenuItem.Text = "Database Backup";
            // 
            // restoreDataBaseToolStripMenuItem
            // 
            this.restoreDataBaseToolStripMenuItem.BackColor = System.Drawing.Color.DarkSlateGray;
            this.restoreDataBaseToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restoreDataBaseToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.restoreDataBaseToolStripMenuItem.Name = "restoreDataBaseToolStripMenuItem";
            this.restoreDataBaseToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.restoreDataBaseToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.restoreDataBaseToolStripMenuItem.Text = " Database Recovery";
            // 
            // logsToolStripMenuItem
            // 
            this.logsToolStripMenuItem.BackColor = System.Drawing.Color.DarkSlateGray;
            this.logsToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.logsToolStripMenuItem.Name = "logsToolStripMenuItem";
            this.logsToolStripMenuItem.Size = new System.Drawing.Size(50, 22);
            this.logsToolStripMenuItem.Text = "Logs";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.BackColor = System.Drawing.Color.DarkSlateGray;
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(50, 22);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // logoutToolStripMenuItem1
            // 
            this.logoutToolStripMenuItem1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.logoutToolStripMenuItem1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.logoutToolStripMenuItem1.Name = "logoutToolStripMenuItem1";
            this.logoutToolStripMenuItem1.Size = new System.Drawing.Size(64, 22);
            this.logoutToolStripMenuItem1.Text = "Logout";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // menuStrip3
            // 
            this.menuStrip3.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterEntryToolStripMenuItem,
            this.loginDetailsToolStripMenuItem1,
            this.profileEntryToolStripMenuItem,
            this.studentToolStripMenuItem2,
            this.transactionToolStripMenuItem1,
            this.recordsToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.databaseBackupToolStripMenuItem1,
            this.databaseRecoveryToolStripMenuItem1,
            this.logsToolStripMenuItem2,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.logoutToolStripMenuItem2});
            this.menuStrip3.Location = new System.Drawing.Point(0, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(1358, 26);
            this.menuStrip3.TabIndex = 1;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // masterEntryToolStripMenuItem
            // 
            this.masterEntryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SchooltoolStripMenuItem4,
            this.classToolStripMenuItem1,
            this.sectionToolStripMenuItem,
            this.departmentToolStripMenuItem1,
            this.toolStripMenuItem5,
            this.toolStripMenuItem4,
            this.eventToolStripMenuItem2,
            this.feeEntryToolStripMenuItem1,
            this.transportationToolStripMenuItem1,
            this.hostelEntryToolStripMenuItem,
            this.eventToolStripMenuItem3,
            this.scholarshipEntryToolStripMenuItem,
            this.subjectEntryToolStripMenuItem,
            this.marksEntryToolStripMenuItem,
            this.examsEntryToolStripMenuItem});
            this.masterEntryToolStripMenuItem.Name = "masterEntryToolStripMenuItem";
            this.masterEntryToolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.masterEntryToolStripMenuItem.Text = "&Master Entry";
            this.masterEntryToolStripMenuItem.Click += new System.EventHandler(this.masterEntryToolStripMenuItem_Click);
            // 
            // SchooltoolStripMenuItem4
            // 
            this.SchooltoolStripMenuItem4.Name = "SchooltoolStripMenuItem4";
            this.SchooltoolStripMenuItem4.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.SchooltoolStripMenuItem4.Size = new System.Drawing.Size(253, 22);
            this.SchooltoolStripMenuItem4.Text = "School Entry";
            this.SchooltoolStripMenuItem4.Click += new System.EventHandler(this.SchooltoolStripMenuItem4_Click);
            // 
            // classToolStripMenuItem1
            // 
            this.classToolStripMenuItem1.Name = "classToolStripMenuItem1";
            this.classToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.classToolStripMenuItem1.Size = new System.Drawing.Size(253, 22);
            this.classToolStripMenuItem1.Text = "Class";
            this.classToolStripMenuItem1.Click += new System.EventHandler(this.classToolStripMenuItem1_Click);
            // 
            // sectionToolStripMenuItem
            // 
            this.sectionToolStripMenuItem.Name = "sectionToolStripMenuItem";
            this.sectionToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.sectionToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.sectionToolStripMenuItem.Text = "Section";
            this.sectionToolStripMenuItem.Click += new System.EventHandler(this.sectionToolStripMenuItem_Click);
            // 
            // departmentToolStripMenuItem1
            // 
            this.departmentToolStripMenuItem1.Name = "departmentToolStripMenuItem1";
            this.departmentToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.departmentToolStripMenuItem1.Size = new System.Drawing.Size(253, 22);
            this.departmentToolStripMenuItem1.Text = "Department";
            this.departmentToolStripMenuItem1.Click += new System.EventHandler(this.departmentToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.toolStripMenuItem5.Size = new System.Drawing.Size(253, 22);
            this.toolStripMenuItem5.Text = "Book Entry";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.toolStripMenuItem4.Size = new System.Drawing.Size(253, 22);
            this.toolStripMenuItem4.Text = "Fee Category";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click_1);
            // 
            // eventToolStripMenuItem2
            // 
            this.eventToolStripMenuItem2.Name = "eventToolStripMenuItem2";
            this.eventToolStripMenuItem2.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.B)));
            this.eventToolStripMenuItem2.Size = new System.Drawing.Size(253, 22);
            this.eventToolStripMenuItem2.Text = "Book Suppliers";
            this.eventToolStripMenuItem2.Click += new System.EventHandler(this.eventToolStripMenuItem2_Click);
            // 
            // feeEntryToolStripMenuItem1
            // 
            this.feeEntryToolStripMenuItem1.Name = "feeEntryToolStripMenuItem1";
            this.feeEntryToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.feeEntryToolStripMenuItem1.Size = new System.Drawing.Size(253, 22);
            this.feeEntryToolStripMenuItem1.Text = "Class Fee Entry";
            this.feeEntryToolStripMenuItem1.Click += new System.EventHandler(this.feeEntryToolStripMenuItem1_Click);
            // 
            // transportationToolStripMenuItem1
            // 
            this.transportationToolStripMenuItem1.Name = "transportationToolStripMenuItem1";
            this.transportationToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.transportationToolStripMenuItem1.Size = new System.Drawing.Size(253, 22);
            this.transportationToolStripMenuItem1.Text = "Transportation";
            this.transportationToolStripMenuItem1.Click += new System.EventHandler(this.transportationToolStripMenuItem1_Click);
            // 
            // hostelEntryToolStripMenuItem
            // 
            this.hostelEntryToolStripMenuItem.Name = "hostelEntryToolStripMenuItem";
            this.hostelEntryToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.hostelEntryToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.hostelEntryToolStripMenuItem.Text = "Hostel Entry";
            this.hostelEntryToolStripMenuItem.Click += new System.EventHandler(this.hostelEntryToolStripMenuItem_Click);
            // 
            // eventToolStripMenuItem3
            // 
            this.eventToolStripMenuItem3.Name = "eventToolStripMenuItem3";
            this.eventToolStripMenuItem3.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.eventToolStripMenuItem3.Size = new System.Drawing.Size(253, 22);
            this.eventToolStripMenuItem3.Text = "Event";
            this.eventToolStripMenuItem3.Click += new System.EventHandler(this.eventToolStripMenuItem3_Click);
            // 
            // scholarshipEntryToolStripMenuItem
            // 
            this.scholarshipEntryToolStripMenuItem.Name = "scholarshipEntryToolStripMenuItem";
            this.scholarshipEntryToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt)
                        | System.Windows.Forms.Keys.S)));
            this.scholarshipEntryToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.scholarshipEntryToolStripMenuItem.Text = "Scholarship Entry";
            this.scholarshipEntryToolStripMenuItem.Click += new System.EventHandler(this.scholarshipEntryToolStripMenuItem_Click);
            // 
            // subjectEntryToolStripMenuItem
            // 
            this.subjectEntryToolStripMenuItem.Name = "subjectEntryToolStripMenuItem";
            this.subjectEntryToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.subjectEntryToolStripMenuItem.Text = "Subject Entry";
            this.subjectEntryToolStripMenuItem.Click += new System.EventHandler(this.subjectEntryToolStripMenuItem_Click);
            // 
            // marksEntryToolStripMenuItem
            // 
            this.marksEntryToolStripMenuItem.Name = "marksEntryToolStripMenuItem";
            this.marksEntryToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.marksEntryToolStripMenuItem.Text = "Marks Entry";
            this.marksEntryToolStripMenuItem.Click += new System.EventHandler(this.marksEntryToolStripMenuItem_Click);
            // 
            // examsEntryToolStripMenuItem
            // 
            this.examsEntryToolStripMenuItem.Name = "examsEntryToolStripMenuItem";
            this.examsEntryToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.examsEntryToolStripMenuItem.Text = "Exams Entry";
            this.examsEntryToolStripMenuItem.Click += new System.EventHandler(this.examsEntryToolStripMenuItem_Click);
            // 
            // loginDetailsToolStripMenuItem1
            // 
            this.loginDetailsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrationToolStripMenuItem2,
            this.loginDetailsToolStripMenuItem2});
            this.loginDetailsToolStripMenuItem1.Name = "loginDetailsToolStripMenuItem1";
            this.loginDetailsToolStripMenuItem1.Size = new System.Drawing.Size(54, 22);
            this.loginDetailsToolStripMenuItem1.Text = "Users";
            // 
            // registrationToolStripMenuItem2
            // 
            this.registrationToolStripMenuItem2.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe1;
            this.registrationToolStripMenuItem2.Name = "registrationToolStripMenuItem2";
            this.registrationToolStripMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.registrationToolStripMenuItem2.Text = "Registration";
            this.registrationToolStripMenuItem2.Click += new System.EventHandler(this.registrationToolStripMenuItem2_Click_1);
            // 
            // loginDetailsToolStripMenuItem2
            // 
            this.loginDetailsToolStripMenuItem2.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe1;
            this.loginDetailsToolStripMenuItem2.Name = "loginDetailsToolStripMenuItem2";
            this.loginDetailsToolStripMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.loginDetailsToolStripMenuItem2.Text = "Login Details";
            this.loginDetailsToolStripMenuItem2.Click += new System.EventHandler(this.loginDetailsToolStripMenuItem2_Click);
            // 
            // profileEntryToolStripMenuItem
            // 
            this.profileEntryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.profileEntryToolStripMenuItem1});
            this.profileEntryToolStripMenuItem.Name = "profileEntryToolStripMenuItem";
            this.profileEntryToolStripMenuItem.Size = new System.Drawing.Size(81, 22);
            this.profileEntryToolStripMenuItem.Text = "Employee";
            this.profileEntryToolStripMenuItem.Click += new System.EventHandler(this.profileEntryToolStripMenuItem_Click);
            // 
            // profileEntryToolStripMenuItem1
            // 
            this.profileEntryToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.employeesIcon200;
            this.profileEntryToolStripMenuItem1.Name = "profileEntryToolStripMenuItem1";
            this.profileEntryToolStripMenuItem1.Size = new System.Drawing.Size(151, 22);
            this.profileEntryToolStripMenuItem1.Text = "Profile Entry";
            this.profileEntryToolStripMenuItem1.Click += new System.EventHandler(this.profileEntryToolStripMenuItem1_Click);
            // 
            // studentToolStripMenuItem2
            // 
            this.studentToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.profileEntryToolStripMenuItem2,
            this.hostelersToolStripMenuItem2,
            this.busCardHoldersToolStripMenuItem});
            this.studentToolStripMenuItem2.Name = "studentToolStripMenuItem2";
            this.studentToolStripMenuItem2.Size = new System.Drawing.Size(67, 22);
            this.studentToolStripMenuItem2.Text = "Student";
            this.studentToolStripMenuItem2.Click += new System.EventHandler(this.studentToolStripMenuItem2_Click);
            // 
            // profileEntryToolStripMenuItem2
            // 
            this.profileEntryToolStripMenuItem2.Image = global::school_management_system.Properties.Resources.education_management2;
            this.profileEntryToolStripMenuItem2.Name = "profileEntryToolStripMenuItem2";
            this.profileEntryToolStripMenuItem2.Size = new System.Drawing.Size(186, 22);
            this.profileEntryToolStripMenuItem2.Text = "Profile Entry";
            this.profileEntryToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.profileEntryToolStripMenuItem2.Click += new System.EventHandler(this.profileEntryToolStripMenuItem2_Click);
            // 
            // hostelersToolStripMenuItem2
            // 
            this.hostelersToolStripMenuItem2.Image = global::school_management_system.Properties.Resources.education_management2;
            this.hostelersToolStripMenuItem2.Name = "hostelersToolStripMenuItem2";
            this.hostelersToolStripMenuItem2.Size = new System.Drawing.Size(186, 22);
            this.hostelersToolStripMenuItem2.Text = "Hostelers";
            this.hostelersToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.hostelersToolStripMenuItem2.Click += new System.EventHandler(this.hostelersToolStripMenuItem2_Click);
            // 
            // busCardHoldersToolStripMenuItem
            // 
            this.busCardHoldersToolStripMenuItem.Image = global::school_management_system.Properties.Resources.education_management2;
            this.busCardHoldersToolStripMenuItem.Name = "busCardHoldersToolStripMenuItem";
            this.busCardHoldersToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.busCardHoldersToolStripMenuItem.Text = "Bus Card  Holders";
            this.busCardHoldersToolStripMenuItem.Click += new System.EventHandler(this.busCardHoldersToolStripMenuItem_Click);
            // 
            // transactionToolStripMenuItem1
            // 
            this.transactionToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ClassFeePaymentToolStripMenuItem3,
            this.busFeePaymentToolStripMenuItem4,
            this.hostelFeePaymentToolStripMenuItem3,
            this.scholarshipPaymentToolStripMenuItem2,
            this.employeeSalaryPaymentToolStripMenuItem,
            this.bookIssueToolStripMenuItem1,
            this.bookReturnToolStripMenuItem});
            this.transactionToolStripMenuItem1.Name = "transactionToolStripMenuItem1";
            this.transactionToolStripMenuItem1.Size = new System.Drawing.Size(92, 22);
            this.transactionToolStripMenuItem1.Text = "Transaction";
            // 
            // ClassFeePaymentToolStripMenuItem3
            // 
            this.ClassFeePaymentToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe1;
            this.ClassFeePaymentToolStripMenuItem3.Name = "ClassFeePaymentToolStripMenuItem3";
            this.ClassFeePaymentToolStripMenuItem3.Size = new System.Drawing.Size(204, 22);
            this.ClassFeePaymentToolStripMenuItem3.Text = "Class Fee Payment";
            this.ClassFeePaymentToolStripMenuItem3.Click += new System.EventHandler(this.busFeePaymentToolStripMenuItem3_Click);
            // 
            // busFeePaymentToolStripMenuItem4
            // 
            this.busFeePaymentToolStripMenuItem4.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe1;
            this.busFeePaymentToolStripMenuItem4.Name = "busFeePaymentToolStripMenuItem4";
            this.busFeePaymentToolStripMenuItem4.Size = new System.Drawing.Size(204, 22);
            this.busFeePaymentToolStripMenuItem4.Text = "Bus Fee Payment";
            this.busFeePaymentToolStripMenuItem4.Click += new System.EventHandler(this.busFeePaymentToolStripMenuItem4_Click);
            // 
            // hostelFeePaymentToolStripMenuItem3
            // 
            this.hostelFeePaymentToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe1;
            this.hostelFeePaymentToolStripMenuItem3.Name = "hostelFeePaymentToolStripMenuItem3";
            this.hostelFeePaymentToolStripMenuItem3.Size = new System.Drawing.Size(204, 22);
            this.hostelFeePaymentToolStripMenuItem3.Text = "Hostel Fee Payment";
            this.hostelFeePaymentToolStripMenuItem3.Click += new System.EventHandler(this.hostelFeePaymentToolStripMenuItem3_Click);
            // 
            // scholarshipPaymentToolStripMenuItem2
            // 
            this.scholarshipPaymentToolStripMenuItem2.Image = global::school_management_system.Properties.Resources.moey;
            this.scholarshipPaymentToolStripMenuItem2.Name = "scholarshipPaymentToolStripMenuItem2";
            this.scholarshipPaymentToolStripMenuItem2.Size = new System.Drawing.Size(204, 22);
            this.scholarshipPaymentToolStripMenuItem2.Text = "Scholarship Payment";
            this.scholarshipPaymentToolStripMenuItem2.Click += new System.EventHandler(this.scholarshipPaymentToolStripMenuItem2_Click);
            // 
            // employeeSalaryPaymentToolStripMenuItem
            // 
            this.employeeSalaryPaymentToolStripMenuItem.Image = global::school_management_system.Properties.Resources.moey;
            this.employeeSalaryPaymentToolStripMenuItem.Name = "employeeSalaryPaymentToolStripMenuItem";
            this.employeeSalaryPaymentToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.employeeSalaryPaymentToolStripMenuItem.Text = " Salary Payment";
            this.employeeSalaryPaymentToolStripMenuItem.Click += new System.EventHandler(this.employeeSalaryPaymentToolStripMenuItem_Click);
            // 
            // bookIssueToolStripMenuItem1
            // 
            this.bookIssueToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.rwererwerrwes1;
            this.bookIssueToolStripMenuItem1.Name = "bookIssueToolStripMenuItem1";
            this.bookIssueToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.bookIssueToolStripMenuItem1.Text = "Book Issue";
            this.bookIssueToolStripMenuItem1.Click += new System.EventHandler(this.bookIssueToolStripMenuItem1_Click_1);
            // 
            // bookReturnToolStripMenuItem
            // 
            this.bookReturnToolStripMenuItem.Image = global::school_management_system.Properties.Resources.images;
            this.bookReturnToolStripMenuItem.Name = "bookReturnToolStripMenuItem";
            this.bookReturnToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.bookReturnToolStripMenuItem.Text = "Book Return";
            this.bookReturnToolStripMenuItem.Click += new System.EventHandler(this.bookReturnToolStripMenuItem_Click);
            // 
            // recordsToolStripMenuItem
            // 
            this.recordsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentsToolStripMenuItem1,
            this.hostelersToolStripMenuItem3,
            this.busHoldersToolStripMenuItem3,
            this.employeesToolStripMenuItem,
            this.toolStripMenuItem6,
            this.claToolStripMenuItem,
            this.busFeePaymentToolStripMenuItem5,
            this.scholarshipPaymentToolStripMenuItem3,
            this.hostelFeePaymentToolStripMenuItem4,
            this.BookstoolStripMenuItem6,
            this.bookIssueStudentToolStripMenuItem,
            this.bookIssueStaffToolStripMenuItem,
            this.bookReturnStudentToolStripMenuItem,
            this.bookReturnToolStripMenuItem1,
            this.eventRecordsToolStripMenuItem1,
            this.subjectRecordsToolStripMenuItem,
            this.marksRecordToolStripMenuItem});
            this.recordsToolStripMenuItem.Name = "recordsToolStripMenuItem";
            this.recordsToolStripMenuItem.Size = new System.Drawing.Size(69, 22);
            this.recordsToolStripMenuItem.Text = "Records";
            // 
            // studentsToolStripMenuItem1
            // 
            this.studentsToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.education_management3;
            this.studentsToolStripMenuItem1.Name = "studentsToolStripMenuItem1";
            this.studentsToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.studentsToolStripMenuItem1.Text = "Students";
            this.studentsToolStripMenuItem1.Click += new System.EventHandler(this.studentsToolStripMenuItem1_Click);
            // 
            // hostelersToolStripMenuItem3
            // 
            this.hostelersToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.education_management3;
            this.hostelersToolStripMenuItem3.Name = "hostelersToolStripMenuItem3";
            this.hostelersToolStripMenuItem3.Size = new System.Drawing.Size(204, 22);
            this.hostelersToolStripMenuItem3.Text = "Hostelers";
            this.hostelersToolStripMenuItem3.Click += new System.EventHandler(this.hostelersToolStripMenuItem3_Click);
            // 
            // busHoldersToolStripMenuItem3
            // 
            this.busHoldersToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.education_management3;
            this.busHoldersToolStripMenuItem3.Name = "busHoldersToolStripMenuItem3";
            this.busHoldersToolStripMenuItem3.Size = new System.Drawing.Size(204, 22);
            this.busHoldersToolStripMenuItem3.Text = "Bus Holders";
            this.busHoldersToolStripMenuItem3.Click += new System.EventHandler(this.busHoldersToolStripMenuItem3_Click);
            // 
            // employeesToolStripMenuItem
            // 
            this.employeesToolStripMenuItem.Image = global::school_management_system.Properties.Resources.employeesIcon200;
            this.employeesToolStripMenuItem.Name = "employeesToolStripMenuItem";
            this.employeesToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.employeesToolStripMenuItem.Text = "Employees";
            this.employeesToolStripMenuItem.Click += new System.EventHandler(this.employeesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Image = global::school_management_system.Properties.Resources.moey;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(204, 22);
            this.toolStripMenuItem6.Text = "Salary Payment";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // claToolStripMenuItem
            // 
            this.claToolStripMenuItem.Image = global::school_management_system.Properties.Resources.yellow_comment_bubbles_icon_culture_book212;
            this.claToolStripMenuItem.Name = "claToolStripMenuItem";
            this.claToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.claToolStripMenuItem.Text = "Class Fee Payment";
            this.claToolStripMenuItem.Click += new System.EventHandler(this.claToolStripMenuItem_Click);
            // 
            // busFeePaymentToolStripMenuItem5
            // 
            this.busFeePaymentToolStripMenuItem5.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.busFeePaymentToolStripMenuItem5.Name = "busFeePaymentToolStripMenuItem5";
            this.busFeePaymentToolStripMenuItem5.Size = new System.Drawing.Size(204, 22);
            this.busFeePaymentToolStripMenuItem5.Text = "Bus Fee Payment";
            this.busFeePaymentToolStripMenuItem5.Click += new System.EventHandler(this.busFeePaymentToolStripMenuItem5_Click);
            // 
            // scholarshipPaymentToolStripMenuItem3
            // 
            this.scholarshipPaymentToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.scholarshipPaymentToolStripMenuItem3.Name = "scholarshipPaymentToolStripMenuItem3";
            this.scholarshipPaymentToolStripMenuItem3.Size = new System.Drawing.Size(204, 22);
            this.scholarshipPaymentToolStripMenuItem3.Text = "Scholarship Payment";
            this.scholarshipPaymentToolStripMenuItem3.Click += new System.EventHandler(this.scholarshipPaymentToolStripMenuItem3_Click);
            // 
            // hostelFeePaymentToolStripMenuItem4
            // 
            this.hostelFeePaymentToolStripMenuItem4.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.hostelFeePaymentToolStripMenuItem4.Name = "hostelFeePaymentToolStripMenuItem4";
            this.hostelFeePaymentToolStripMenuItem4.Size = new System.Drawing.Size(204, 22);
            this.hostelFeePaymentToolStripMenuItem4.Text = "Hostel Fee Payment";
            this.hostelFeePaymentToolStripMenuItem4.Click += new System.EventHandler(this.hostelFeePaymentToolStripMenuItem4_Click);
            // 
            // BookstoolStripMenuItem6
            // 
            this.BookstoolStripMenuItem6.Image = global::school_management_system.Properties.Resources.wrwrwrwrwserw;
            this.BookstoolStripMenuItem6.Name = "BookstoolStripMenuItem6";
            this.BookstoolStripMenuItem6.Size = new System.Drawing.Size(204, 22);
            this.BookstoolStripMenuItem6.Text = "Books";
            this.BookstoolStripMenuItem6.Click += new System.EventHandler(this.BookstoolStripMenuItem6_Click);
            // 
            // bookIssueStudentToolStripMenuItem
            // 
            this.bookIssueStudentToolStripMenuItem.Image = global::school_management_system.Properties.Resources.wrwrwrwrwserw;
            this.bookIssueStudentToolStripMenuItem.Name = "bookIssueStudentToolStripMenuItem";
            this.bookIssueStudentToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.bookIssueStudentToolStripMenuItem.Text = "Book Issue Student";
            this.bookIssueStudentToolStripMenuItem.Click += new System.EventHandler(this.bookIssueStudentToolStripMenuItem_Click_1);
            // 
            // bookIssueStaffToolStripMenuItem
            // 
            this.bookIssueStaffToolStripMenuItem.Image = global::school_management_system.Properties.Resources.werewsrewrew;
            this.bookIssueStaffToolStripMenuItem.Name = "bookIssueStaffToolStripMenuItem";
            this.bookIssueStaffToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.bookIssueStaffToolStripMenuItem.Text = "Book Issue Staff";
            this.bookIssueStaffToolStripMenuItem.Click += new System.EventHandler(this.bookIssueStaffToolStripMenuItem_Click_1);
            // 
            // bookReturnStudentToolStripMenuItem
            // 
            this.bookReturnStudentToolStripMenuItem.Image = global::school_management_system.Properties.Resources.wrwrwrwrwserw;
            this.bookReturnStudentToolStripMenuItem.Name = "bookReturnStudentToolStripMenuItem";
            this.bookReturnStudentToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.bookReturnStudentToolStripMenuItem.Text = "Book Return Student";
            this.bookReturnStudentToolStripMenuItem.Click += new System.EventHandler(this.bookReturnStudentToolStripMenuItem_Click);
            // 
            // bookReturnToolStripMenuItem1
            // 
            this.bookReturnToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.rwererwerrwes2;
            this.bookReturnToolStripMenuItem1.Name = "bookReturnToolStripMenuItem1";
            this.bookReturnToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.bookReturnToolStripMenuItem1.Text = " Book Return Staff";
            this.bookReturnToolStripMenuItem1.Click += new System.EventHandler(this.bookReturnToolStripMenuItem1_Click_1);
            // 
            // eventRecordsToolStripMenuItem1
            // 
            this.eventRecordsToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe2;
            this.eventRecordsToolStripMenuItem1.Name = "eventRecordsToolStripMenuItem1";
            this.eventRecordsToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.eventRecordsToolStripMenuItem1.Text = "Event Records";
            this.eventRecordsToolStripMenuItem1.Click += new System.EventHandler(this.eventRecordsToolStripMenuItem1_Click);
            // 
            // subjectRecordsToolStripMenuItem
            // 
            this.subjectRecordsToolStripMenuItem.Image = global::school_management_system.Properties.Resources.education_management3;
            this.subjectRecordsToolStripMenuItem.Name = "subjectRecordsToolStripMenuItem";
            this.subjectRecordsToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.subjectRecordsToolStripMenuItem.Text = "Subject Records";
            this.subjectRecordsToolStripMenuItem.Click += new System.EventHandler(this.subjectRecordsToolStripMenuItem_Click);
            // 
            // marksRecordToolStripMenuItem
            // 
            this.marksRecordToolStripMenuItem.Image = global::school_management_system.Properties.Resources.education_management3;
            this.marksRecordToolStripMenuItem.Name = "marksRecordToolStripMenuItem";
            this.marksRecordToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.marksRecordToolStripMenuItem.Text = "Marks Record";
            this.marksRecordToolStripMenuItem.Click += new System.EventHandler(this.marksRecordToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.busHoldersToolStripMenuItem4,
            this.hostelersToolStripMenuItem4,
            this.classFeePaymentToolStripMenuItem,
            this.salaryPaymentToolStripMenuItem3,
            this.busFeePaymentReportToolStripMenuItem,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.studentMarksReportToolStripMenuItem,
            this.studentReportToolStripMenuItem,
            this.employeeReportToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // busHoldersToolStripMenuItem4
            // 
            this.busHoldersToolStripMenuItem4.Image = global::school_management_system.Properties.Resources.education_management3;
            this.busHoldersToolStripMenuItem4.Name = "busHoldersToolStripMenuItem4";
            this.busHoldersToolStripMenuItem4.Size = new System.Drawing.Size(245, 22);
            this.busHoldersToolStripMenuItem4.Text = "BusHolders Report";
            this.busHoldersToolStripMenuItem4.Click += new System.EventHandler(this.busHoldersToolStripMenuItem4_Click);
            // 
            // hostelersToolStripMenuItem4
            // 
            this.hostelersToolStripMenuItem4.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.hostelersToolStripMenuItem4.Name = "hostelersToolStripMenuItem4";
            this.hostelersToolStripMenuItem4.Size = new System.Drawing.Size(245, 22);
            this.hostelersToolStripMenuItem4.Text = "Hostelers Report";
            this.hostelersToolStripMenuItem4.Click += new System.EventHandler(this.hostelersToolStripMenuItem4_Click);
            // 
            // classFeePaymentToolStripMenuItem
            // 
            this.classFeePaymentToolStripMenuItem.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.classFeePaymentToolStripMenuItem.Name = "classFeePaymentToolStripMenuItem";
            this.classFeePaymentToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.classFeePaymentToolStripMenuItem.Text = "ClassFeePaymentReport";
            this.classFeePaymentToolStripMenuItem.Click += new System.EventHandler(this.classFeePaymentToolStripMenuItem_Click);
            // 
            // salaryPaymentToolStripMenuItem3
            // 
            this.salaryPaymentToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.salaryPaymentToolStripMenuItem3.Name = "salaryPaymentToolStripMenuItem3";
            this.salaryPaymentToolStripMenuItem3.Size = new System.Drawing.Size(245, 22);
            this.salaryPaymentToolStripMenuItem3.Text = "SalaryPaymentReport";
            this.salaryPaymentToolStripMenuItem3.Click += new System.EventHandler(this.salaryPaymentToolStripMenuItem3_Click);
            // 
            // busFeePaymentReportToolStripMenuItem
            // 
            this.busFeePaymentReportToolStripMenuItem.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.busFeePaymentReportToolStripMenuItem.Name = "busFeePaymentReportToolStripMenuItem";
            this.busFeePaymentReportToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.busFeePaymentReportToolStripMenuItem.Text = "BusFeePaymentReport";
            this.busFeePaymentReportToolStripMenuItem.Click += new System.EventHandler(this.busFeePaymentReportToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(245, 22);
            this.toolStripMenuItem7.Text = "HostelFeePaymentReport";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe;
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(245, 22);
            this.toolStripMenuItem8.Text = "ScholarshipPayment Report";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // studentMarksReportToolStripMenuItem
            // 
            this.studentMarksReportToolStripMenuItem.Image = global::school_management_system.Properties.Resources.education_management3;
            this.studentMarksReportToolStripMenuItem.Name = "studentMarksReportToolStripMenuItem";
            this.studentMarksReportToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.studentMarksReportToolStripMenuItem.Text = "Student Marks Report";
            this.studentMarksReportToolStripMenuItem.Click += new System.EventHandler(this.studentMarksReportToolStripMenuItem_Click);
            // 
            // studentReportToolStripMenuItem
            // 
            this.studentReportToolStripMenuItem.Image = global::school_management_system.Properties.Resources.education_management3;
            this.studentReportToolStripMenuItem.Name = "studentReportToolStripMenuItem";
            this.studentReportToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.studentReportToolStripMenuItem.Text = "Student Report";
            this.studentReportToolStripMenuItem.Click += new System.EventHandler(this.studentReportToolStripMenuItem_Click);
            // 
            // employeeReportToolStripMenuItem
            // 
            this.employeeReportToolStripMenuItem.Image = global::school_management_system.Properties.Resources.wqeqweqweqewwqe1;
            this.employeeReportToolStripMenuItem.Name = "employeeReportToolStripMenuItem";
            this.employeeReportToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.employeeReportToolStripMenuItem.Text = "Employee Report";
            this.employeeReportToolStripMenuItem.Click += new System.EventHandler(this.employeeReportToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculatorToolStripMenuItem1,
            this.notepadToolStripMenuItem1,
            this.taskManagerToolStripMenuItem1,
            this.mSWordToolStripMenuItem1,
            this.wordpadToolStripMenuItem1});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(55, 22);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // calculatorToolStripMenuItem1
            // 
            this.calculatorToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.calculatorToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.calc;
            this.calculatorToolStripMenuItem1.Name = "calculatorToolStripMenuItem1";
            this.calculatorToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.calculatorToolStripMenuItem1.Text = "Calculator";
            this.calculatorToolStripMenuItem1.Click += new System.EventHandler(this.calculatorToolStripMenuItem1_Click);
            // 
            // notepadToolStripMenuItem1
            // 
            this.notepadToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.Notepad1;
            this.notepadToolStripMenuItem1.Name = "notepadToolStripMenuItem1";
            this.notepadToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.notepadToolStripMenuItem1.Text = "Notepad";
            this.notepadToolStripMenuItem1.Click += new System.EventHandler(this.notepadToolStripMenuItem1_Click);
            // 
            // taskManagerToolStripMenuItem1
            // 
            this.taskManagerToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.task_manager1;
            this.taskManagerToolStripMenuItem1.Name = "taskManagerToolStripMenuItem1";
            this.taskManagerToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.taskManagerToolStripMenuItem1.Text = "Task Manager";
            this.taskManagerToolStripMenuItem1.Click += new System.EventHandler(this.taskManagerToolStripMenuItem1_Click);
            // 
            // mSWordToolStripMenuItem1
            // 
            this.mSWordToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.MS_Word_2_icon1;
            this.mSWordToolStripMenuItem1.Name = "mSWordToolStripMenuItem1";
            this.mSWordToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.mSWordToolStripMenuItem1.Text = "MS Word";
            this.mSWordToolStripMenuItem1.Click += new System.EventHandler(this.mSWordToolStripMenuItem1_Click);
            // 
            // wordpadToolStripMenuItem1
            // 
            this.wordpadToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.Wordpad_icon__Windows_7_11;
            this.wordpadToolStripMenuItem1.Name = "wordpadToolStripMenuItem1";
            this.wordpadToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.wordpadToolStripMenuItem1.Text = "Wordpad";
            this.wordpadToolStripMenuItem1.Click += new System.EventHandler(this.wordpadToolStripMenuItem1_Click);
            // 
            // databaseBackupToolStripMenuItem1
            // 
            this.databaseBackupToolStripMenuItem1.Name = "databaseBackupToolStripMenuItem1";
            this.databaseBackupToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.databaseBackupToolStripMenuItem1.Text = "Database Backup";
            this.databaseBackupToolStripMenuItem1.Click += new System.EventHandler(this.databaseBackupToolStripMenuItem1_Click);
            // 
            // databaseRecoveryToolStripMenuItem1
            // 
            this.databaseRecoveryToolStripMenuItem1.Name = "databaseRecoveryToolStripMenuItem1";
            this.databaseRecoveryToolStripMenuItem1.Size = new System.Drawing.Size(139, 22);
            this.databaseRecoveryToolStripMenuItem1.Text = " Database Recovery";
            this.databaseRecoveryToolStripMenuItem1.Click += new System.EventHandler(this.databaseRecoveryToolStripMenuItem1_Click);
            // 
            // logsToolStripMenuItem2
            // 
            this.logsToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.logsToolStripMenuItem2.Name = "logsToolStripMenuItem2";
            this.logsToolStripMenuItem2.Size = new System.Drawing.Size(50, 22);
            this.logsToolStripMenuItem2.Text = "Logs";
            this.logsToolStripMenuItem2.Click += new System.EventHandler(this.logsToolStripMenuItem2_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(58, 22);
            this.toolStripMenuItem9.Text = "About";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(50, 22);
            this.toolStripMenuItem10.Text = "Help";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // logoutToolStripMenuItem2
            // 
            this.logoutToolStripMenuItem2.Name = "logoutToolStripMenuItem2";
            this.logoutToolStripMenuItem2.Size = new System.Drawing.Size(64, 22);
            this.logoutToolStripMenuItem2.Text = "Logout";
            this.logoutToolStripMenuItem2.Click += new System.EventHandler(this.logoutToolStripMenuItem2_Click);
            // 
            // statusStrip2
            // 
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel2,
            this.UserType,
            this.User,
            this.toolStripStatusLabel3,
            this.Time});
            this.statusStrip2.Location = new System.Drawing.Point(0, 562);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(1358, 23);
            this.statusStrip2.TabIndex = 3;
            this.statusStrip2.Text = "statusStrip2";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(88, 18);
            this.toolStripStatusLabel2.Text = "Logged In As :";
            // 
            // UserType
            // 
            this.UserType.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserType.ForeColor = System.Drawing.Color.DarkMagenta;
            this.UserType.Name = "UserType";
            this.UserType.Size = new System.Drawing.Size(62, 18);
            this.UserType.Text = "UserType";
            this.UserType.Visible = false;
            // 
            // User
            // 
            this.User.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.User.ForeColor = System.Drawing.Color.DarkRed;
            this.User.Image = global::school_management_system.Properties.Resources.education_management11;
            this.User.Name = "User";
            this.User.Size = new System.Drawing.Size(49, 18);
            this.User.Text = "User";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.ForeColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(1039, 18);
            this.toolStripStatusLabel3.Text = resources.GetString("toolStripStatusLabel3.Text");
            // 
            // Time
            // 
            this.Time.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Time.ForeColor = System.Drawing.Color.Maroon;
            this.Time.Image = global::school_management_system.Properties.Resources.time_1920x12001;
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(51, 18);
            this.Time.Text = "time";
            this.Time.Click += new System.EventHandler(this.toolStripStatusLabel4_Click);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // bookIssueToolStripMenuItem
            // 
            this.bookIssueToolStripMenuItem.Image = global::school_management_system.Properties.Resources.wrwrwrwrwserw;
            this.bookIssueToolStripMenuItem.Name = "bookIssueToolStripMenuItem";
            this.bookIssueToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.bookIssueToolStripMenuItem.Text = "Book Issue ";
            // 
            // BookretunToolStripMenuItem
            // 
            this.BookretunToolStripMenuItem.Image = global::school_management_system.Properties.Resources.werewsrewrew;
            this.BookretunToolStripMenuItem.Name = "BookretunToolStripMenuItem";
            this.BookretunToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.BookretunToolStripMenuItem.Text = "Book Return";
            // 
            // registrationToolStripMenuItem3
            // 
            this.registrationToolStripMenuItem3.BackColor = System.Drawing.Color.Transparent;
            this.registrationToolStripMenuItem3.BackgroundImage = global::school_management_system.Properties.Resources.abstract_set_awesome_14495691;
            this.registrationToolStripMenuItem3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.registrationToolStripMenuItem3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registrationToolStripMenuItem3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.registrationToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.registration_icon_up;
            this.registrationToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.registrationToolStripMenuItem3.Name = "registrationToolStripMenuItem3";
            this.registrationToolStripMenuItem3.Size = new System.Drawing.Size(86, 76);
            this.registrationToolStripMenuItem3.Text = "Registration";
            this.registrationToolStripMenuItem3.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.registrationToolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // studentToolStripMenuItem1
            // 
            this.studentToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.studentToolStripMenuItem1.BackgroundImage = global::school_management_system.Properties.Resources.abstract_set_awesome_14495692;
            this.studentToolStripMenuItem1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.studentToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.employeesIcon2001;
            this.studentToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.studentToolStripMenuItem1.Name = "studentToolStripMenuItem1";
            this.studentToolStripMenuItem1.Size = new System.Drawing.Size(67, 76);
            this.studentToolStripMenuItem1.Text = "Student";
            this.studentToolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.studentToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // employeeToolStripMenuItem1
            // 
            this.employeeToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.employeeToolStripMenuItem1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("employeeToolStripMenuItem1.BackgroundImage")));
            this.employeeToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeToolStripMenuItem1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.employeeToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.teacher_icon1;
            this.employeeToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.employeeToolStripMenuItem1.Name = "employeeToolStripMenuItem1";
            this.employeeToolStripMenuItem1.Size = new System.Drawing.Size(81, 76);
            this.employeeToolStripMenuItem1.Text = "Employee";
            this.employeeToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toolStripMenuItem3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem3.BackgroundImage")));
            this.toolStripMenuItem3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.toolStripMenuItem3.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toolStripMenuItem3.Image = global::school_management_system.Properties.Resources.url1;
            this.toolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(62, 76);
            this.toolStripMenuItem3.Text = "Books";
            this.toolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // salaryPaymentToolStripMenuItem
            // 
            this.salaryPaymentToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.salaryPaymentToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("salaryPaymentToolStripMenuItem.BackgroundImage")));
            this.salaryPaymentToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.salaryPaymentToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salaryPaymentToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.salaryPaymentToolStripMenuItem.Image = global::school_management_system.Properties.Resources.salary_icon1;
            this.salaryPaymentToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.salaryPaymentToolStripMenuItem.Name = "salaryPaymentToolStripMenuItem";
            this.salaryPaymentToolStripMenuItem.Size = new System.Drawing.Size(114, 76);
            this.salaryPaymentToolStripMenuItem.Text = "Salary Payment";
            this.salaryPaymentToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.salaryPaymentToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // feePaymentToolStripMenuItem1
            // 
            this.feePaymentToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.feePaymentToolStripMenuItem1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("feePaymentToolStripMenuItem1.BackgroundImage")));
            this.feePaymentToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.feePaymentToolStripMenuItem1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feePaymentToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.feePaymentToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.yellow_comment_bubbles_icon_culture_book212;
            this.feePaymentToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.feePaymentToolStripMenuItem1.Name = "feePaymentToolStripMenuItem1";
            this.feePaymentToolStripMenuItem1.Size = new System.Drawing.Size(122, 76);
            this.feePaymentToolStripMenuItem1.Text = "Class Fee Payment";
            this.feePaymentToolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.feePaymentToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toolStripMenuItem1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.BackgroundImage")));
            this.toolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toolStripMenuItem1.Image = global::school_management_system.Properties.Resources.yellow_comment_bubbles_icon_culture_book212;
            this.toolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(124, 76);
            this.toolStripMenuItem1.Text = "Bus Fee Payment";
            this.toolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // hostelFeePaymentToolStripMenuItem2
            // 
            this.hostelFeePaymentToolStripMenuItem2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.hostelFeePaymentToolStripMenuItem2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hostelFeePaymentToolStripMenuItem2.BackgroundImage")));
            this.hostelFeePaymentToolStripMenuItem2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hostelFeePaymentToolStripMenuItem2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hostelFeePaymentToolStripMenuItem2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.hostelFeePaymentToolStripMenuItem2.Image = global::school_management_system.Properties.Resources.yellow_comment_bubbles_icon_culture_book213;
            this.hostelFeePaymentToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.hostelFeePaymentToolStripMenuItem2.Name = "hostelFeePaymentToolStripMenuItem2";
            this.hostelFeePaymentToolStripMenuItem2.Size = new System.Drawing.Size(129, 76);
            this.hostelFeePaymentToolStripMenuItem2.Text = "Hostel Fee Payment";
            this.hostelFeePaymentToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toolStripMenuItem2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem2.BackgroundImage")));
            this.toolStripMenuItem2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.toolStripMenuItem2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toolStripMenuItem2.Image = global::school_management_system.Properties.Resources.yellow_comment_bubbles_icon_culture_book21;
            this.toolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(148, 76);
            this.toolStripMenuItem2.Text = "Scholarship Payment";
            this.toolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // databaseBakupToolStripMenuItem
            // 
            this.databaseBakupToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.databaseBakupToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("databaseBakupToolStripMenuItem.BackgroundImage")));
            this.databaseBakupToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.databaseBakupToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.databaseBakupToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.databaseBakupToolStripMenuItem.Image = global::school_management_system.Properties.Resources.database_icon1;
            this.databaseBakupToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.databaseBakupToolStripMenuItem.Name = "databaseBakupToolStripMenuItem";
            this.databaseBakupToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.databaseBakupToolStripMenuItem.Size = new System.Drawing.Size(120, 76);
            this.databaseBakupToolStripMenuItem.Text = "Database Bakup";
            this.databaseBakupToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.databaseBakupToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // databaseRecoveryToolStripMenuItem
            // 
            this.databaseRecoveryToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.databaseRecoveryToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("databaseRecoveryToolStripMenuItem.BackgroundImage")));
            this.databaseRecoveryToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.databaseRecoveryToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.databaseRecoveryToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.databaseRecoveryToolStripMenuItem.Image = global::school_management_system.Properties.Resources.database_icon2;
            this.databaseRecoveryToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.databaseRecoveryToolStripMenuItem.Name = "databaseRecoveryToolStripMenuItem";
            this.databaseRecoveryToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.databaseRecoveryToolStripMenuItem.Size = new System.Drawing.Size(125, 76);
            this.databaseRecoveryToolStripMenuItem.Text = "Database Recovery";
            this.databaseRecoveryToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // logsToolStripMenuItem1
            // 
            this.logsToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.logsToolStripMenuItem1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logsToolStripMenuItem1.BackgroundImage")));
            this.logsToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logsToolStripMenuItem1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logsToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.logsToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.log_1281;
            this.logsToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.logsToolStripMenuItem1.Name = "logsToolStripMenuItem1";
            this.logsToolStripMenuItem1.Size = new System.Drawing.Size(62, 76);
            this.logsToolStripMenuItem1.Text = "Logs";
            this.logsToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.logoutToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logoutToolStripMenuItem.BackgroundImage")));
            this.logoutToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.logoutToolStripMenuItem.Image = global::school_management_system.Properties.Resources.img_transaction_icon;
            this.logoutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(67, 76);
            this.logoutToolStripMenuItem.Text = "Help";
            this.logoutToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // logouToolStripMenuItem
            // 
            this.logouToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.logouToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logouToolStripMenuItem.BackgroundImage")));
            this.logouToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logouToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logouToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.logouToolStripMenuItem.Image = global::school_management_system.Properties.Resources.logout1;
            this.logouToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.logouToolStripMenuItem.Name = "logouToolStripMenuItem";
            this.logouToolStripMenuItem.Size = new System.Drawing.Size(62, 76);
            this.logouToolStripMenuItem.Text = "Logout";
            this.logouToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // logToolStripMenuItem
            // 
            this.logToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.logToolStripMenuItem.Image = global::school_management_system.Properties.Resources.registration_icon_up;
            this.logToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.logToolStripMenuItem.Name = "logToolStripMenuItem";
            this.logToolStripMenuItem.Size = new System.Drawing.Size(86, 72);
            this.logToolStripMenuItem.Text = "Registration";
            this.logToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.logToolStripMenuItem.Click += new System.EventHandler(this.logToolStripMenuItem_Click);
            // 
            // studentToolStripMenuItem3
            // 
            this.studentToolStripMenuItem3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentToolStripMenuItem3.ForeColor = System.Drawing.Color.Black;
            this.studentToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.employeesIcon200;
            this.studentToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.studentToolStripMenuItem3.Name = "studentToolStripMenuItem3";
            this.studentToolStripMenuItem3.Size = new System.Drawing.Size(101, 72);
            this.studentToolStripMenuItem3.Text = "Student Profile";
            this.studentToolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.studentToolStripMenuItem3.Click += new System.EventHandler(this.studentToolStripMenuItem3_Click);
            // 
            // employeeToolStripMenuItem3
            // 
            this.employeeToolStripMenuItem3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeToolStripMenuItem3.ForeColor = System.Drawing.Color.Black;
            this.employeeToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.teacher_icon;
            this.employeeToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.employeeToolStripMenuItem3.Name = "employeeToolStripMenuItem3";
            this.employeeToolStripMenuItem3.Size = new System.Drawing.Size(113, 72);
            this.employeeToolStripMenuItem3.Text = "Employee Profile";
            this.employeeToolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.employeeToolStripMenuItem3.Click += new System.EventHandler(this.employeeToolStripMenuItem3_Click);
            // 
            // salaryPaymentToolStripMenuItem2
            // 
            this.salaryPaymentToolStripMenuItem2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salaryPaymentToolStripMenuItem2.ForeColor = System.Drawing.Color.Black;
            this.salaryPaymentToolStripMenuItem2.Image = global::school_management_system.Properties.Resources.Salaries_sml;
            this.salaryPaymentToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.salaryPaymentToolStripMenuItem2.Name = "salaryPaymentToolStripMenuItem2";
            this.salaryPaymentToolStripMenuItem2.Size = new System.Drawing.Size(106, 72);
            this.salaryPaymentToolStripMenuItem2.Text = "Salary Payment";
            this.salaryPaymentToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.salaryPaymentToolStripMenuItem2.Click += new System.EventHandler(this.salaryPaymentToolStripMenuItem2_Click);
            // 
            // feePaymentToolStripMenuItem3
            // 
            this.feePaymentToolStripMenuItem3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feePaymentToolStripMenuItem3.ForeColor = System.Drawing.Color.Black;
            this.feePaymentToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.education_management2;
            this.feePaymentToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.feePaymentToolStripMenuItem3.Name = "feePaymentToolStripMenuItem3";
            this.feePaymentToolStripMenuItem3.Size = new System.Drawing.Size(133, 72);
            this.feePaymentToolStripMenuItem3.Text = "Class  Fees  Payment";
            this.feePaymentToolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.feePaymentToolStripMenuItem3.Click += new System.EventHandler(this.feePaymentToolStripMenuItem3_Click);
            // 
            // hostelFeePaymentToolStripMenuItem5
            // 
            this.hostelFeePaymentToolStripMenuItem5.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hostelFeePaymentToolStripMenuItem5.ForeColor = System.Drawing.Color.Black;
            this.hostelFeePaymentToolStripMenuItem5.Image = global::school_management_system.Properties.Resources.rtewtete3;
            this.hostelFeePaymentToolStripMenuItem5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.hostelFeePaymentToolStripMenuItem5.Name = "hostelFeePaymentToolStripMenuItem5";
            this.hostelFeePaymentToolStripMenuItem5.Size = new System.Drawing.Size(134, 72);
            this.hostelFeePaymentToolStripMenuItem5.Text = "Hostel Fees Payment";
            this.hostelFeePaymentToolStripMenuItem5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.hostelFeePaymentToolStripMenuItem5.Click += new System.EventHandler(this.hostelFeePaymentToolStripMenuItem5_Click);
            // 
            // busFeePaymentToolStripMenuItem3
            // 
            this.busFeePaymentToolStripMenuItem3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busFeePaymentToolStripMenuItem3.ForeColor = System.Drawing.Color.Black;
            this.busFeePaymentToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.images__3_1;
            this.busFeePaymentToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.busFeePaymentToolStripMenuItem3.Name = "busFeePaymentToolStripMenuItem3";
            this.busFeePaymentToolStripMenuItem3.Size = new System.Drawing.Size(119, 72);
            this.busFeePaymentToolStripMenuItem3.Text = "Bus Fees Payment";
            this.busFeePaymentToolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.busFeePaymentToolStripMenuItem3.Click += new System.EventHandler(this.busFeePaymentToolStripMenuItem3_Click_1);
            // 
            // scholarshipPaymentToolStripMenuItem4
            // 
            this.scholarshipPaymentToolStripMenuItem4.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scholarshipPaymentToolStripMenuItem4.ForeColor = System.Drawing.Color.Black;
            this.scholarshipPaymentToolStripMenuItem4.Image = global::school_management_system.Properties.Resources.images__5_1;
            this.scholarshipPaymentToolStripMenuItem4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.scholarshipPaymentToolStripMenuItem4.Name = "scholarshipPaymentToolStripMenuItem4";
            this.scholarshipPaymentToolStripMenuItem4.Size = new System.Drawing.Size(134, 72);
            this.scholarshipPaymentToolStripMenuItem4.Text = "Scholarship Payment";
            this.scholarshipPaymentToolStripMenuItem4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.scholarshipPaymentToolStripMenuItem4.Click += new System.EventHandler(this.scholarshipPaymentToolStripMenuItem4_Click);
            // 
            // databaseBackupToolStripMenuItem2
            // 
            this.databaseBackupToolStripMenuItem2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.databaseBackupToolStripMenuItem2.ForeColor = System.Drawing.Color.Black;
            this.databaseBackupToolStripMenuItem2.Image = global::school_management_system.Properties.Resources._31307856_back_up_icon_internet_button_on_white_background1;
            this.databaseBackupToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.databaseBackupToolStripMenuItem2.Name = "databaseBackupToolStripMenuItem2";
            this.databaseBackupToolStripMenuItem2.Size = new System.Drawing.Size(119, 72);
            this.databaseBackupToolStripMenuItem2.Text = "Database  Backup.";
            this.databaseBackupToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.databaseBackupToolStripMenuItem2.Click += new System.EventHandler(this.databaseBackupToolStripMenuItem2_Click);
            // 
            // databaseRecoveryToolStripMenuItem2
            // 
            this.databaseRecoveryToolStripMenuItem2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.databaseRecoveryToolStripMenuItem2.ForeColor = System.Drawing.Color.Black;
            this.databaseRecoveryToolStripMenuItem2.Image = global::school_management_system.Properties.Resources.database_icon2;
            this.databaseRecoveryToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.databaseRecoveryToolStripMenuItem2.Name = "databaseRecoveryToolStripMenuItem2";
            this.databaseRecoveryToolStripMenuItem2.Size = new System.Drawing.Size(125, 72);
            this.databaseRecoveryToolStripMenuItem2.Text = "Database Recovery";
            this.databaseRecoveryToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.databaseRecoveryToolStripMenuItem2.Click += new System.EventHandler(this.databaseRecoveryToolStripMenuItem2_Click);
            // 
            // logsToolStripMenuItem3
            // 
            this.logsToolStripMenuItem3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logsToolStripMenuItem3.ForeColor = System.Drawing.Color.Black;
            this.logsToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.imagesf;
            this.logsToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.logsToolStripMenuItem3.Name = "logsToolStripMenuItem3";
            this.logsToolStripMenuItem3.Size = new System.Drawing.Size(63, 72);
            this.logsToolStripMenuItem3.Text = "Logs";
            this.logsToolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.logsToolStripMenuItem3.Click += new System.EventHandler(this.logsToolStripMenuItem3_Click_1);
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.helpToolStripMenuItem1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem1.ForeColor = System.Drawing.Color.Black;
            this.helpToolStripMenuItem1.Image = global::school_management_system.Properties.Resources.fhfhh1;
            this.helpToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(62, 72);
            this.helpToolStripMenuItem1.Text = "Help..";
            this.helpToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.helpToolStripMenuItem1.Click += new System.EventHandler(this.helpToolStripMenuItem1_Click);
            // 
            // logoutToolStripMenuItem3
            // 
            this.logoutToolStripMenuItem3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem3.ForeColor = System.Drawing.Color.Black;
            this.logoutToolStripMenuItem3.Image = global::school_management_system.Properties.Resources.images__28_;
            this.logoutToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.logoutToolStripMenuItem3.Name = "logoutToolStripMenuItem3";
            this.logoutToolStripMenuItem3.Size = new System.Drawing.Size(66, 72);
            this.logoutToolStripMenuItem3.Text = "Logout..";
            this.logoutToolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.logoutToolStripMenuItem3.Click += new System.EventHandler(this.logoutToolStripMenuItem3_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logToolStripMenuItem,
            this.studentToolStripMenuItem3,
            this.employeeToolStripMenuItem3,
            this.salaryPaymentToolStripMenuItem2,
            this.feePaymentToolStripMenuItem3,
            this.hostelFeePaymentToolStripMenuItem5,
            this.busFeePaymentToolStripMenuItem3,
            this.scholarshipPaymentToolStripMenuItem4,
            this.databaseBackupToolStripMenuItem2,
            this.databaseRecoveryToolStripMenuItem2,
            this.logsToolStripMenuItem3,
            this.helpToolStripMenuItem1,
            this.logoutToolStripMenuItem3});
            this.menuStrip1.Location = new System.Drawing.Point(-1, 26);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1369, 76);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked_1);
            // 
            // frm_Main_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = global::school_management_system.Properties.Resources.bigstock_back_to_school_supplies_and_bo_21368879;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1358, 585);
            this.Controls.Add(this.statusStrip2);
            this.Controls.Add(this.menuStrip3);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frm_Main_Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Menu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_Main_Menu_Load);
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ToolStripMenuItem Master_entryMenu;
        private System.Windows.Forms.ToolStripMenuItem ClassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SectionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem departmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eventToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feesDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hostelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scholarshipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem BooksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transportationToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem usersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem studentDetailsToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem hostelersToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem busHoldersToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem employeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeProfileToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem busFeePaymentToolStripMenuItem2;
        public System.Windows.Forms.ToolStripMenuItem feePaymentToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem employeeSalaryToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem hostelFeesPaymentToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem scholarshipPaymentToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hostlersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem busHoldersToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem studentProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attendanceToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem feesDetailsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem internalMarksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem salaryPaymentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem salarySlipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feePaymentToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem feeReceiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scholarshipPaymentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem hostelFeePaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersTransactionToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem busFeePaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scholarshipPaymentReceiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem busFeePaymentReceiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hostelFeePaymentReceiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem transportationChargesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem subjectInfoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem EventtoolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolsMenu;
        private System.Windows.Forms.ToolStripMenuItem calculatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notepadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taskManagerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mSWordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wordpadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem BooksuppliersToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem bookIssueToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem BookretunToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem studentRecordToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem hostelersToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem busHoldersToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem employeeRecordToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem feePaymentRecordToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem employeePaymentRecordToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem hostelFeePaymentToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem busFeePaymentToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem scholarshipPaymentRecordToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem bookIssueRToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem bookissueStaffsToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem bookReturnstudentsToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem bookReturnStaffToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem dataBaseBackUpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreDataBaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feeEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem schoolEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eventRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookEntryRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem employeeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem salaryPaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feePaymentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem hostelFeePaymentToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem databaseBakupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem databaseRecoveryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logouToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem masterEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SchooltoolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem classToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem departmentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem eventToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem feeEntryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem transportationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem hostelEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eventToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem loginDetailsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem profileEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem profileEntryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem profileEntryToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem hostelersToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem busCardHoldersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ClassFeePaymentToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem busFeePaymentToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem hostelFeePaymentToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem scholarshipPaymentToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem employeeSalaryPaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookIssueToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bookReturnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem hostelersToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem busHoldersToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem employeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem claToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem busFeePaymentToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem scholarshipPaymentToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem hostelFeePaymentToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem BookstoolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem bookIssueStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookIssueStaffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookReturnStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookReturnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eventRecordsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculatorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem notepadToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem taskManagerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mSWordToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem wordpadToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem databaseBackupToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem databaseRecoveryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem logsToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem loginDetailsToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem scholarshipEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        public System.Windows.Forms.ToolStripStatusLabel UserType;
        public System.Windows.Forms.ToolStripStatusLabel User;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel Time;
        private System.Windows.Forms.ToolStripMenuItem busHoldersToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem hostelersToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem classFeePaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salaryPaymentToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem busFeePaymentReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem logToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem employeeToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem salaryPaymentToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem feePaymentToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem hostelFeePaymentToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem busFeePaymentToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem scholarshipPaymentToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem databaseBackupToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem databaseRecoveryToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem logsToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem subjectEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marksEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentMarksReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem subjectRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marksRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem examsEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeReportToolStripMenuItem;
    }
}