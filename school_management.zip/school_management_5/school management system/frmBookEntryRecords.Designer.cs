﻿namespace school_management_system
{
    partial class frmBookEntryRecords
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBookEntryRecords));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblUserType = new System.Windows.Forms.Label();
            this.set = new System.Windows.Forms.Label();
            this.GroupBox15 = new System.Windows.Forms.GroupBox();
            this.txtBookTitle = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ExportExcel = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.cmbBookTitle = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.GroupBox19 = new System.Windows.Forms.GroupBox();
            this.txtJointAuthors = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.GroupBox14 = new System.Windows.Forms.GroupBox();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbAuthor = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtAccessionNo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbAccessionNo = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.GroupBox9 = new System.Windows.Forms.GroupBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.cmbSubject = new System.Windows.Forms.ComboBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.TabPage6 = new System.Windows.Forms.TabPage();
            this.GroupBox16 = new System.Windows.Forms.GroupBox();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.GroupBox17 = new System.Windows.Forms.GroupBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.GroupBox18 = new System.Windows.Forms.GroupBox();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.DataGridView6 = new System.Windows.Forms.DataGridView();
            this.TabPage7 = new System.Windows.Forms.TabPage();
            this.DataGridView7 = new System.Windows.Forms.DataGridView();
            this.GroupBox22 = new System.Windows.Forms.GroupBox();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button13 = new System.Windows.Forms.Button();
            this.GroupBox20 = new System.Windows.Forms.GroupBox();
            this.txtRFBooks = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.GroupBox21 = new System.Windows.Forms.GroupBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.cmbRfBook = new System.Windows.Forms.ComboBox();
            this.TabPage8 = new System.Windows.Forms.TabPage();
            this.DataGridView8 = new System.Windows.Forms.DataGridView();
            this.GroupBox23 = new System.Windows.Forms.GroupBox();
            this.Button16 = new System.Windows.Forms.Button();
            this.Button14 = new System.Windows.Forms.Button();
            this.Button15 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.GroupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.GroupBox19.SuspendLayout();
            this.GroupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.GroupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.TabPage6.SuspendLayout();
            this.GroupBox16.SuspendLayout();
            this.GroupBox17.SuspendLayout();
            this.GroupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView6)).BeginInit();
            this.TabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView7)).BeginInit();
            this.GroupBox22.SuspendLayout();
            this.GroupBox20.SuspendLayout();
            this.GroupBox21.SuspendLayout();
            this.TabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView8)).BeginInit();
            this.GroupBox23.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.TabPage6);
            this.tabControl1.Controls.Add(this.TabPage7);
            this.tabControl1.Controls.Add(this.TabPage8);
            this.tabControl1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(-5, 1);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1206, 555);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblUser);
            this.tabPage1.Controls.Add(this.lblUserType);
            this.tabPage1.Controls.Add(this.set);
            this.tabPage1.Controls.Add(this.GroupBox15);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.GroupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1198, 525);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "By Book Title";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(673, 341);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(33, 17);
            this.lblUser.TabIndex = 83;
            this.lblUser.Text = "User";
            this.lblUser.Visible = false;
            // 
            // lblUserType
            // 
            this.lblUserType.AutoSize = true;
            this.lblUserType.Location = new System.Drawing.Point(673, 373);
            this.lblUserType.Name = "lblUserType";
            this.lblUserType.Size = new System.Drawing.Size(62, 17);
            this.lblUserType.TabIndex = 82;
            this.lblUserType.Text = "UserType";
            this.lblUserType.Visible = false;
            // 
            // set
            // 
            this.set.AutoSize = true;
            this.set.Location = new System.Drawing.Point(1091, 64);
            this.set.Name = "set";
            this.set.Size = new System.Drawing.Size(39, 17);
            this.set.TabIndex = 23;
            this.set.Text = "label4";
            this.set.Visible = false;
            // 
            // GroupBox15
            // 
            this.GroupBox15.Controls.Add(this.txtBookTitle);
            this.GroupBox15.Controls.Add(this.Label10);
            this.GroupBox15.Location = new System.Drawing.Point(290, 8);
            this.GroupBox15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox15.Name = "GroupBox15";
            this.GroupBox15.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox15.Size = new System.Drawing.Size(271, 114);
            this.GroupBox15.TabIndex = 22;
            this.GroupBox15.TabStop = false;
            // 
            // txtBookTitle
            // 
            this.txtBookTitle.Location = new System.Drawing.Point(33, 58);
            this.txtBookTitle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBookTitle.Name = "txtBookTitle";
            this.txtBookTitle.Size = new System.Drawing.Size(214, 24);
            this.txtBookTitle.TabIndex = 9;
            this.txtBookTitle.TextChanged += new System.EventHandler(this.txtBookTitle_TextChanged);
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(29, 26);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(72, 18);
            this.Label10.TabIndex = 8;
            this.Label10.Text = "Book Title";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 136);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1186, 274);
            this.dataGridView1.TabIndex = 21;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView1_RowPostPaint);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ExportExcel);
            this.groupBox6.Controls.Add(this.button6);
            this.groupBox6.Location = new System.Drawing.Point(571, 8);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Size = new System.Drawing.Size(232, 111);
            this.groupBox6.TabIndex = 20;
            this.groupBox6.TabStop = false;
            // 
            // ExportExcel
            // 
            this.ExportExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExportExcel.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExportExcel.Location = new System.Drawing.Point(126, 49);
            this.ExportExcel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ExportExcel.Name = "ExportExcel";
            this.ExportExcel.Size = new System.Drawing.Size(83, 30);
            this.ExportExcel.TabIndex = 4;
            this.ExportExcel.Text = "&Export Excel";
            this.ExportExcel.UseVisualStyleBackColor = true;
            this.ExportExcel.Click += new System.EventHandler(this.ExportExcel_Click);
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(20, 49);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(83, 30);
            this.button6.TabIndex = 1;
            this.button6.Text = "&Reset";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Controls.Add(this.cmbBookTitle);
            this.GroupBox1.Location = new System.Drawing.Point(7, 8);
            this.GroupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox1.Size = new System.Drawing.Size(261, 114);
            this.GroupBox1.TabIndex = 18;
            this.GroupBox1.TabStop = false;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(28, 24);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(72, 18);
            this.Label3.TabIndex = 10;
            this.Label3.Text = "Book Title";
            // 
            // cmbBookTitle
            // 
            this.cmbBookTitle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbBookTitle.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBookTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBookTitle.FormattingEnabled = true;
            this.cmbBookTitle.Location = new System.Drawing.Point(31, 56);
            this.cmbBookTitle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbBookTitle.Name = "cmbBookTitle";
            this.cmbBookTitle.Size = new System.Drawing.Size(210, 23);
            this.cmbBookTitle.TabIndex = 9;
            this.cmbBookTitle.SelectedIndexChanged += new System.EventHandler(this.cmbBookTitle_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.GroupBox19);
            this.tabPage2.Controls.Add(this.GroupBox14);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(1198, 525);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "By Author";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // GroupBox19
            // 
            this.GroupBox19.Controls.Add(this.txtJointAuthors);
            this.GroupBox19.Controls.Add(this.Label13);
            this.GroupBox19.Location = new System.Drawing.Point(556, 9);
            this.GroupBox19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox19.Name = "GroupBox19";
            this.GroupBox19.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox19.Size = new System.Drawing.Size(224, 114);
            this.GroupBox19.TabIndex = 25;
            this.GroupBox19.TabStop = false;
            // 
            // txtJointAuthors
            // 
            this.txtJointAuthors.Location = new System.Drawing.Point(33, 55);
            this.txtJointAuthors.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtJointAuthors.Name = "txtJointAuthors";
            this.txtJointAuthors.Size = new System.Drawing.Size(177, 24);
            this.txtJointAuthors.TabIndex = 9;
            this.txtJointAuthors.TextChanged += new System.EventHandler(this.txtJointAuthors_TextChanged);
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(29, 26);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(88, 18);
            this.Label13.TabIndex = 8;
            this.Label13.Text = "Joint Authors";
            // 
            // GroupBox14
            // 
            this.GroupBox14.Controls.Add(this.txtAuthor);
            this.GroupBox14.Controls.Add(this.Label9);
            this.GroupBox14.Location = new System.Drawing.Point(310, 8);
            this.GroupBox14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox14.Name = "GroupBox14";
            this.GroupBox14.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox14.Size = new System.Drawing.Size(235, 114);
            this.GroupBox14.TabIndex = 23;
            this.GroupBox14.TabStop = false;
            // 
            // txtAuthor
            // 
            this.txtAuthor.Location = new System.Drawing.Point(33, 55);
            this.txtAuthor.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(187, 24);
            this.txtAuthor.TabIndex = 9;
            this.txtAuthor.TextChanged += new System.EventHandler(this.txtAuthor_TextChanged);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(29, 26);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(50, 18);
            this.Label9.TabIndex = 8;
            this.Label9.Text = "Author";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(9, 131);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(1174, 274);
            this.dataGridView2.TabIndex = 22;
            this.dataGridView2.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView2_RowHeaderMouseClick);
            this.dataGridView2.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView2_RowPostPaint);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label6);
            this.groupBox8.Controls.Add(this.cmbAuthor);
            this.groupBox8.Location = new System.Drawing.Point(9, 8);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox8.Size = new System.Drawing.Size(266, 114);
            this.groupBox8.TabIndex = 16;
            this.groupBox8.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(29, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 18);
            this.label6.TabIndex = 8;
            this.label6.Text = "Author";
            // 
            // cmbAuthor
            // 
            this.cmbAuthor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbAuthor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAuthor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAuthor.FormattingEnabled = true;
            this.cmbAuthor.Location = new System.Drawing.Point(33, 58);
            this.cmbAuthor.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbAuthor.Name = "cmbAuthor";
            this.cmbAuthor.Size = new System.Drawing.Size(213, 23);
            this.cmbAuthor.TabIndex = 7;
            this.cmbAuthor.SelectedIndexChanged += new System.EventHandler(this.cmbAuthor_SelectedIndexChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button7);
            this.groupBox7.Controls.Add(this.button9);
            this.groupBox7.Location = new System.Drawing.Point(799, 9);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Size = new System.Drawing.Size(219, 113);
            this.groupBox7.TabIndex = 17;
            this.groupBox7.TabStop = false;
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(124, 44);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(83, 33);
            this.button7.TabIndex = 4;
            this.button7.Text = "&Export Excel";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(19, 45);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 32);
            this.button9.TabIndex = 1;
            this.button9.Text = "&Reset";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3.Size = new System.Drawing.Size(1198, 525);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "By Accession No.";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Location = new System.Drawing.Point(544, 20);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(236, 113);
            this.groupBox4.TabIndex = 24;
            this.groupBox4.TabStop = false;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(130, 51);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 30);
            this.button1.TabIndex = 4;
            this.button1.Text = "&Export Excel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(22, 51);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(83, 30);
            this.button2.TabIndex = 1;
            this.button2.Text = "&Reset";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(9, 141);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView3.MultiSelect = false;
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1183, 274);
            this.dataGridView3.TabIndex = 23;
            this.dataGridView3.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView3_RowHeaderMouseClick);
            this.dataGridView3.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView3_RowPostPaint);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtAccessionNo);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(287, 19);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(227, 114);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            // 
            // txtAccessionNo
            // 
            this.txtAccessionNo.Location = new System.Drawing.Point(20, 59);
            this.txtAccessionNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAccessionNo.Name = "txtAccessionNo";
            this.txtAccessionNo.Size = new System.Drawing.Size(185, 24);
            this.txtAccessionNo.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(17, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 18);
            this.label8.TabIndex = 8;
            this.label8.Text = "Accession No.";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cmbAccessionNo);
            this.groupBox2.Location = new System.Drawing.Point(9, 20);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(240, 114);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 18);
            this.label7.TabIndex = 8;
            this.label7.Text = "Accession No.";
            // 
            // cmbAccessionNo
            // 
            this.cmbAccessionNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbAccessionNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAccessionNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAccessionNo.FormattingEnabled = true;
            this.cmbAccessionNo.Location = new System.Drawing.Point(20, 58);
            this.cmbAccessionNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbAccessionNo.Name = "cmbAccessionNo";
            this.cmbAccessionNo.Size = new System.Drawing.Size(200, 23);
            this.cmbAccessionNo.TabIndex = 7;
            this.cmbAccessionNo.SelectedIndexChanged += new System.EventHandler(this.cmbAccessionNo_SelectedIndexChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.GroupBox5);
            this.tabPage4.Controls.Add(this.GroupBox9);
            this.tabPage4.Controls.Add(this.groupBox10);
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage4.Size = new System.Drawing.Size(1198, 525);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "By Subject";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.txtSubject);
            this.GroupBox5.Controls.Add(this.Label1);
            this.GroupBox5.Location = new System.Drawing.Point(284, 6);
            this.GroupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox5.Size = new System.Drawing.Size(239, 114);
            this.GroupBox5.TabIndex = 26;
            this.GroupBox5.TabStop = false;
            // 
            // txtSubject
            // 
            this.txtSubject.Location = new System.Drawing.Point(20, 60);
            this.txtSubject.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(186, 24);
            this.txtSubject.TabIndex = 9;
            this.txtSubject.TextChanged += new System.EventHandler(this.txtSubject_TextChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(17, 30);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(93, 18);
            this.Label1.TabIndex = 8;
            this.Label1.Text = "Subject Name";
            // 
            // GroupBox9
            // 
            this.GroupBox9.Controls.Add(this.Label2);
            this.GroupBox9.Controls.Add(this.cmbSubject);
            this.GroupBox9.Location = new System.Drawing.Point(9, 8);
            this.GroupBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox9.Name = "GroupBox9";
            this.GroupBox9.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox9.Size = new System.Drawing.Size(231, 112);
            this.GroupBox9.TabIndex = 25;
            this.GroupBox9.TabStop = false;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(29, 26);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(93, 18);
            this.Label2.TabIndex = 8;
            this.Label2.Text = "Subject Name";
            // 
            // cmbSubject
            // 
            this.cmbSubject.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSubject.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSubject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSubject.FormattingEnabled = true;
            this.cmbSubject.Location = new System.Drawing.Point(33, 60);
            this.cmbSubject.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbSubject.Name = "cmbSubject";
            this.cmbSubject.Size = new System.Drawing.Size(174, 23);
            this.cmbSubject.TabIndex = 7;
            this.cmbSubject.SelectedIndexChanged += new System.EventHandler(this.cmbSubject_SelectedIndexChanged);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button3);
            this.groupBox10.Controls.Add(this.button8);
            this.groupBox10.Location = new System.Drawing.Point(547, 8);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox10.Size = new System.Drawing.Size(249, 112);
            this.groupBox10.TabIndex = 24;
            this.groupBox10.TabStop = false;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(135, 52);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 31);
            this.button3.TabIndex = 4;
            this.button3.Text = "&Export Excel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(20, 54);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(80, 28);
            this.button8.TabIndex = 1;
            this.button8.Text = "&Reset";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(9, 128);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView4.MultiSelect = false;
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(1186, 274);
            this.dataGridView4.TabIndex = 22;
            this.dataGridView4.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView4_RowHeaderMouseClick);
            this.dataGridView4.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView4_RowPostPaint);
            // 
            // TabPage6
            // 
            this.TabPage6.Controls.Add(this.GroupBox16);
            this.TabPage6.Controls.Add(this.GroupBox17);
            this.TabPage6.Controls.Add(this.GroupBox18);
            this.TabPage6.Controls.Add(this.DataGridView6);
            this.TabPage6.Location = new System.Drawing.Point(4, 26);
            this.TabPage6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TabPage6.Name = "TabPage6";
            this.TabPage6.Size = new System.Drawing.Size(1198, 525);
            this.TabPage6.TabIndex = 5;
            this.TabPage6.Text = "By Department";
            this.TabPage6.UseVisualStyleBackColor = true;
            // 
            // GroupBox16
            // 
            this.GroupBox16.Controls.Add(this.txtDepartment);
            this.GroupBox16.Controls.Add(this.Label11);
            this.GroupBox16.Location = new System.Drawing.Point(273, 4);
            this.GroupBox16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox16.Name = "GroupBox16";
            this.GroupBox16.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox16.Size = new System.Drawing.Size(192, 114);
            this.GroupBox16.TabIndex = 32;
            this.GroupBox16.TabStop = false;
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(19, 58);
            this.txtDepartment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(162, 24);
            this.txtDepartment.TabIndex = 9;
            this.txtDepartment.TextChanged += new System.EventHandler(this.txtDepartment_TextChanged);
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(16, 26);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(81, 18);
            this.Label11.TabIndex = 8;
            this.Label11.Text = "Department";
            // 
            // GroupBox17
            // 
            this.GroupBox17.Controls.Add(this.Label12);
            this.GroupBox17.Controls.Add(this.cmbDepartment);
            this.GroupBox17.Location = new System.Drawing.Point(8, 3);
            this.GroupBox17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox17.Name = "GroupBox17";
            this.GroupBox17.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox17.Size = new System.Drawing.Size(259, 114);
            this.GroupBox17.TabIndex = 31;
            this.GroupBox17.TabStop = false;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(29, 26);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(81, 18);
            this.Label12.TabIndex = 8;
            this.Label12.Text = "Department";
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbDepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.Location = new System.Drawing.Point(33, 58);
            this.cmbDepartment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(196, 23);
            this.cmbDepartment.TabIndex = 7;
            this.cmbDepartment.SelectedIndexChanged += new System.EventHandler(this.cmbDepartment_SelectedIndexChanged);
            // 
            // GroupBox18
            // 
            this.GroupBox18.Controls.Add(this.Button4);
            this.GroupBox18.Controls.Add(this.Button11);
            this.GroupBox18.Location = new System.Drawing.Point(483, 8);
            this.GroupBox18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox18.Name = "GroupBox18";
            this.GroupBox18.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox18.Size = new System.Drawing.Size(232, 110);
            this.GroupBox18.TabIndex = 29;
            this.GroupBox18.TabStop = false;
            // 
            // Button4
            // 
            this.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button4.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button4.Location = new System.Drawing.Point(131, 48);
            this.Button4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(83, 30);
            this.Button4.TabIndex = 4;
            this.Button4.Text = "&Export Excel";
            this.Button4.UseVisualStyleBackColor = true;
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Button11
            // 
            this.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button11.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button11.Location = new System.Drawing.Point(15, 50);
            this.Button11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(83, 30);
            this.Button11.TabIndex = 1;
            this.Button11.Text = "&Reset";
            this.Button11.UseVisualStyleBackColor = true;
            this.Button11.Click += new System.EventHandler(this.Button11_Click);
            // 
            // DataGridView6
            // 
            this.DataGridView6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGridView6.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView6.Location = new System.Drawing.Point(8, 123);
            this.DataGridView6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DataGridView6.MultiSelect = false;
            this.DataGridView6.Name = "DataGridView6";
            this.DataGridView6.Size = new System.Drawing.Size(1187, 298);
            this.DataGridView6.TabIndex = 30;
            this.DataGridView6.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGridView6_RowHeaderMouseClick);
            this.DataGridView6.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DataGridView6_RowPostPaint);
            // 
            // TabPage7
            // 
            this.TabPage7.Controls.Add(this.DataGridView7);
            this.TabPage7.Controls.Add(this.GroupBox22);
            this.TabPage7.Controls.Add(this.GroupBox20);
            this.TabPage7.Controls.Add(this.GroupBox21);
            this.TabPage7.Location = new System.Drawing.Point(4, 26);
            this.TabPage7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TabPage7.Name = "TabPage7";
            this.TabPage7.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TabPage7.Size = new System.Drawing.Size(1198, 525);
            this.TabPage7.TabIndex = 6;
            this.TabPage7.Text = "By Reference Books";
            this.TabPage7.UseVisualStyleBackColor = true;
            // 
            // DataGridView7
            // 
            this.DataGridView7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGridView7.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView7.Location = new System.Drawing.Point(6, 105);
            this.DataGridView7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DataGridView7.MultiSelect = false;
            this.DataGridView7.Name = "DataGridView7";
            this.DataGridView7.Size = new System.Drawing.Size(1189, 313);
            this.DataGridView7.TabIndex = 29;
            this.DataGridView7.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGridView7_RowHeaderMouseClick);
            this.DataGridView7.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DataGridView7_RowPostPaint);
            // 
            // GroupBox22
            // 
            this.GroupBox22.Controls.Add(this.Button5);
            this.GroupBox22.Controls.Add(this.Button13);
            this.GroupBox22.Location = new System.Drawing.Point(544, 1);
            this.GroupBox22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox22.Name = "GroupBox22";
            this.GroupBox22.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox22.Size = new System.Drawing.Size(247, 96);
            this.GroupBox22.TabIndex = 30;
            this.GroupBox22.TabStop = false;
            // 
            // Button5
            // 
            this.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button5.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button5.Location = new System.Drawing.Point(138, 49);
            this.Button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(83, 30);
            this.Button5.TabIndex = 4;
            this.Button5.Text = "&Export Excel";
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // Button13
            // 
            this.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button13.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button13.Location = new System.Drawing.Point(26, 49);
            this.Button13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Button13.Name = "Button13";
            this.Button13.Size = new System.Drawing.Size(83, 30);
            this.Button13.TabIndex = 1;
            this.Button13.Text = "&Reset";
            this.Button13.UseVisualStyleBackColor = true;
            this.Button13.Click += new System.EventHandler(this.Button13_Click);
            // 
            // GroupBox20
            // 
            this.GroupBox20.Controls.Add(this.txtRFBooks);
            this.GroupBox20.Controls.Add(this.Label14);
            this.GroupBox20.Location = new System.Drawing.Point(290, 4);
            this.GroupBox20.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox20.Name = "GroupBox20";
            this.GroupBox20.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox20.Size = new System.Drawing.Size(235, 93);
            this.GroupBox20.TabIndex = 28;
            this.GroupBox20.TabStop = false;
            // 
            // txtRFBooks
            // 
            this.txtRFBooks.Location = new System.Drawing.Point(17, 53);
            this.txtRFBooks.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtRFBooks.Name = "txtRFBooks";
            this.txtRFBooks.Size = new System.Drawing.Size(204, 24);
            this.txtRFBooks.TabIndex = 9;
            this.txtRFBooks.TextChanged += new System.EventHandler(this.txtRFBooks_TextChanged);
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label14.Location = new System.Drawing.Point(21, 26);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(105, 18);
            this.Label14.TabIndex = 8;
            this.Label14.Text = "Reference Book";
            // 
            // GroupBox21
            // 
            this.GroupBox21.Controls.Add(this.Label15);
            this.GroupBox21.Controls.Add(this.cmbRfBook);
            this.GroupBox21.Location = new System.Drawing.Point(6, 1);
            this.GroupBox21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox21.Name = "GroupBox21";
            this.GroupBox21.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox21.Size = new System.Drawing.Size(268, 96);
            this.GroupBox21.TabIndex = 27;
            this.GroupBox21.TabStop = false;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label15.Location = new System.Drawing.Point(28, 24);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(105, 18);
            this.Label15.TabIndex = 10;
            this.Label15.Text = "Reference Book";
            // 
            // cmbRfBook
            // 
            this.cmbRfBook.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbRfBook.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRfBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRfBook.FormattingEnabled = true;
            this.cmbRfBook.Location = new System.Drawing.Point(31, 56);
            this.cmbRfBook.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbRfBook.Name = "cmbRfBook";
            this.cmbRfBook.Size = new System.Drawing.Size(203, 23);
            this.cmbRfBook.TabIndex = 9;
            this.cmbRfBook.SelectedIndexChanged += new System.EventHandler(this.cmbRfBook_SelectedIndexChanged);
            // 
            // TabPage8
            // 
            this.TabPage8.Controls.Add(this.DataGridView8);
            this.TabPage8.Controls.Add(this.GroupBox23);
            this.TabPage8.Location = new System.Drawing.Point(4, 26);
            this.TabPage8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TabPage8.Name = "TabPage8";
            this.TabPage8.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TabPage8.Size = new System.Drawing.Size(1198, 525);
            this.TabPage8.TabIndex = 7;
            this.TabPage8.Text = "All Books";
            this.TabPage8.UseVisualStyleBackColor = true;
            // 
            // DataGridView8
            // 
            this.DataGridView8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGridView8.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView8.Location = new System.Drawing.Point(3, 100);
            this.DataGridView8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DataGridView8.MultiSelect = false;
            this.DataGridView8.Name = "DataGridView8";
            this.DataGridView8.Size = new System.Drawing.Size(1189, 313);
            this.DataGridView8.TabIndex = 30;
            this.DataGridView8.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGridView8_RowHeaderMouseClick);
            this.DataGridView8.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DataGridView8_RowPostPaint);
            // 
            // GroupBox23
            // 
            this.GroupBox23.Controls.Add(this.Button16);
            this.GroupBox23.Controls.Add(this.Button14);
            this.GroupBox23.Controls.Add(this.Button15);
            this.GroupBox23.Location = new System.Drawing.Point(6, 8);
            this.GroupBox23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox23.Name = "GroupBox23";
            this.GroupBox23.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GroupBox23.Size = new System.Drawing.Size(335, 84);
            this.GroupBox23.TabIndex = 29;
            this.GroupBox23.TabStop = false;
            // 
            // Button16
            // 
            this.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button16.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button16.Location = new System.Drawing.Point(13, 34);
            this.Button16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Button16.Name = "Button16";
            this.Button16.Size = new System.Drawing.Size(83, 30);
            this.Button16.TabIndex = 5;
            this.Button16.Text = "&Get Data";
            this.Button16.UseVisualStyleBackColor = true;
            this.Button16.Click += new System.EventHandler(this.Button16_Click);
            // 
            // Button14
            // 
            this.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button14.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button14.Location = new System.Drawing.Point(233, 34);
            this.Button14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Button14.Name = "Button14";
            this.Button14.Size = new System.Drawing.Size(83, 30);
            this.Button14.TabIndex = 4;
            this.Button14.Text = "&Export Excel";
            this.Button14.UseVisualStyleBackColor = true;
            this.Button14.Click += new System.EventHandler(this.Button14_Click);
            // 
            // Button15
            // 
            this.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button15.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button15.Location = new System.Drawing.Point(118, 34);
            this.Button15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Button15.Name = "Button15";
            this.Button15.Size = new System.Drawing.Size(83, 30);
            this.Button15.TabIndex = 1;
            this.Button15.Text = "&Reset";
            this.Button15.UseVisualStyleBackColor = true;
            this.Button15.Click += new System.EventHandler(this.Button15_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            // 
            // frmBookEntryRecords
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1121, 453);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmBookEntryRecords";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Book Entry Records";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmBookEntryRecords_FormClosing);
            this.Load += new System.EventHandler(this.frmBookEntryRecords_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.GroupBox15.ResumeLayout(false);
            this.GroupBox15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.GroupBox19.ResumeLayout(false);
            this.GroupBox19.PerformLayout();
            this.GroupBox14.ResumeLayout(false);
            this.GroupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.GroupBox9.ResumeLayout(false);
            this.GroupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.TabPage6.ResumeLayout(false);
            this.GroupBox16.ResumeLayout(false);
            this.GroupBox16.PerformLayout();
            this.GroupBox17.ResumeLayout(false);
            this.GroupBox17.PerformLayout();
            this.GroupBox18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView6)).EndInit();
            this.TabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView7)).EndInit();
            this.GroupBox22.ResumeLayout(false);
            this.GroupBox20.ResumeLayout(false);
            this.GroupBox20.PerformLayout();
            this.GroupBox21.ResumeLayout(false);
            this.GroupBox21.PerformLayout();
            this.TabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView8)).EndInit();
            this.GroupBox23.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox GroupBox15;
        private System.Windows.Forms.TextBox txtBookTitle;
        private System.Windows.Forms.Label Label10;
        public System.Windows.Forms.DataGridView dataGridView1;
        internal System.Windows.Forms.GroupBox groupBox6;
        internal System.Windows.Forms.Button ExportExcel;
        internal System.Windows.Forms.Button button6;
        internal System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.Label Label3;
        public System.Windows.Forms.ComboBox cmbBookTitle;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox GroupBox19;
        private System.Windows.Forms.TextBox txtJointAuthors;
        private System.Windows.Forms.Label Label13;
        private System.Windows.Forms.GroupBox GroupBox14;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.Label Label9;
        public System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.ComboBox cmbAuthor;
        internal System.Windows.Forms.GroupBox groupBox7;
        internal System.Windows.Forms.Button button7;
        internal System.Windows.Forms.Button button9;
        private System.Windows.Forms.TabPage tabPage3;
        internal System.Windows.Forms.GroupBox groupBox4;
        internal System.Windows.Forms.Button button1;
        internal System.Windows.Forms.Button button2;
        public System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtAccessionNo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.ComboBox cmbAccessionNo;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox GroupBox5;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.GroupBox GroupBox9;
        private System.Windows.Forms.Label Label2;
        public System.Windows.Forms.ComboBox cmbSubject;
        internal System.Windows.Forms.GroupBox groupBox10;
        internal System.Windows.Forms.Button button3;
        internal System.Windows.Forms.Button button8;
        public System.Windows.Forms.DataGridView dataGridView4;
        internal System.Windows.Forms.TabPage TabPage6;
        private System.Windows.Forms.GroupBox GroupBox16;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.Label Label11;
        private System.Windows.Forms.GroupBox GroupBox17;
        private System.Windows.Forms.Label Label12;
        public System.Windows.Forms.ComboBox cmbDepartment;
        internal System.Windows.Forms.GroupBox GroupBox18;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Button Button11;
        public System.Windows.Forms.DataGridView DataGridView6;
        internal System.Windows.Forms.TabPage TabPage7;
        public System.Windows.Forms.DataGridView DataGridView7;
        internal System.Windows.Forms.GroupBox GroupBox22;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Button Button13;
        private System.Windows.Forms.GroupBox GroupBox20;
        private System.Windows.Forms.TextBox txtRFBooks;
        private System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.GroupBox GroupBox21;
        private System.Windows.Forms.Label Label15;
        public System.Windows.Forms.ComboBox cmbRfBook;
        internal System.Windows.Forms.TabPage TabPage8;
        public System.Windows.Forms.DataGridView DataGridView8;
        internal System.Windows.Forms.GroupBox GroupBox23;
        internal System.Windows.Forms.Button Button16;
        internal System.Windows.Forms.Button Button14;
        internal System.Windows.Forms.Button Button15;
        public System.Windows.Forms.Label set;
        public System.Windows.Forms.Label lblUser;
        public System.Windows.Forms.Label lblUserType;
        private System.Windows.Forms.Timer timer1;
    }
}