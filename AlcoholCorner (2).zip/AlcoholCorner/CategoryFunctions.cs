﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using AlcoholCorner.DB;
using MySql.Data.MySqlClient;

namespace AlcoholCorner
{
    public class CategoryFunctions
    {
        public List<Category> GetAll()
        {
            var category = new List<Category>();
            DB.DB.getDBConnection().Open();
            {
                MySqlCommand DBCmd = new MySqlCommand();
                DBCmd.Connection = DB.DB.getDBConnection();
                DBCmd.CommandText = "Select * From Categories;";
                MySqlDataReader reader = DBCmd.ExecuteReader();
                {
                    while (reader.Read())
                    {
                        category.Add(new Category
                        {
                            Id = (int)reader["Id"],
                            CategoryName = (string)reader["CategoryName"]
                        });
                    }
                }
            }

            return category;
        }

        public void Add(Category category)
        {
            DB.DB.getDBConnection().Open();
            {
                MySqlCommand DBCmd = new MySqlCommand();
                DBCmd.Connection = DB.DB.getDBConnection();
                DBCmd.CommandText = $"Insert Into Categories (FirstName, LastName) Values ('{category.CategoryName}');";
                DBCmd.ExecuteNonQuery();
            }
        }
        public void Update(Category category)
        {
            DB.DB.getDBConnection().Open();
            {
                MySqlCommand DBCmd = new MySqlCommand();
                DBCmd.Connection = DB.DB.getDBConnection();
                DBCmd.CommandText = $"Update Categories Set CategoryName = '{category.CategoryName}' Where Id = {category.Id};";
                DBCmd.ExecuteNonQuery();
            }
        }

        public void Delete(int id)
        {
            DB.DB.getDBConnection().Open();
            {
                MySqlCommand DBCmd = new MySqlCommand();
                DBCmd.Connection = DB.DB.getDBConnection();
                DBCmd.CommandText = $"Delete From Categories Where Id = {id};";
                DBCmd.ExecuteNonQuery();
            }
        }
    }
}
