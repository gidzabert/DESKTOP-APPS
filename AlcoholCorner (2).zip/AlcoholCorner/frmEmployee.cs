namespace AlcoholCorner
{
    public partial class frmEmployee : Form
    {
        EmployeeFunctions employeeFunctions = new EmployeeFunctions();
        public frmEmployee()
        {
            InitializeComponent();
        }

        private void frmEmployee_Load(object sender, EventArgs e)
        {
            dtView.DataSource = employeeFunctions.GetAll();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtFN.Text) && !string.IsNullOrEmpty(txtS.Text))
            {
                employeeFunctions.Add(new Employee
                {
                    FirstName = txtFN.Text,
                    LastName = txtS.Text,
                });
                txtFN.Text = string.Empty;
                txtS.Text = string.Empty;
                dtView.DataSource = employeeFunctions.GetAll();
            }
        }

 
    }
}