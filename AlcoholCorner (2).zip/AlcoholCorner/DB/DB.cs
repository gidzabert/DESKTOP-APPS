﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;


namespace AlcoholCorner.DB
{
    public static class DB
    {
        static MySqlConnection DBConnection;

        public static MySqlConnection getDBConnection()
        {
            if (DBConnection == null)
            {
                String cstring = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                DBConnection = new MySqlConnection(cstring);
                DBConnection.Open();
            }
            return DBConnection;
        }
    }
}
