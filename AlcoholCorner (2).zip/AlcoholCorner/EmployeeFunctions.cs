﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using AlcoholCorner.DB;
using MySql.Data.MySqlClient;

namespace AlcoholCorner
{
    public class EmployeeFunctions
    {
        public List<Employee> GetAll()
        {
            var employees = new List<Employee>();
            DB.DB.getDBConnection().Open();
            {
                MySqlCommand DBCmd = new MySqlCommand();
                DBCmd.Connection = DB.DB.getDBConnection();
                DBCmd.CommandText = "Select * From Employees;";
                MySqlDataReader reader = DBCmd.ExecuteReader();
                {
                    while (reader.Read())
                    {
                        employees.Add(new Employee
                        {
                            Id = (int)reader["Id"],
                            FirstName = (string)reader["FirstName"],
                            LastName = (string)reader["LastName"]
                        });
                    }
                }
            }

            return employees;
        }

        public void Add(Employee employee)
        {
            DB.DB.getDBConnection().Open();
            {
                MySqlCommand DBCmd = new MySqlCommand();
                DBCmd.Connection = DB.DB.getDBConnection();
                DBCmd.CommandText = $"Insert Into Employees (FirstName, LastName) Values ('{employee.FirstName}', '{employee.LastName}');";
                DBCmd.ExecuteNonQuery();
            }
        }
        public void Update(Employee employee)
        {
            DB.DB.getDBConnection().Open();
            {
                MySqlCommand DBCmd = new MySqlCommand();
                DBCmd.Connection = DB.DB.getDBConnection();
                DBCmd.CommandText = $"Update Employees Set FirstName = '{employee.FirstName}', LastName = '{employee.LastName}' Where Id = {employee.Id};";
                DBCmd.ExecuteNonQuery();
            }
        }

        public void Delete(int id)
        {
            DB.DB.getDBConnection().Open();
            {
                MySqlCommand DBCmd = new MySqlCommand();
                DBCmd.Connection = DB.DB.getDBConnection();
                DBCmd.CommandText = $"Delete From Employees Where Id = {id};";
                DBCmd.ExecuteNonQuery();
            }
        }
    }
}
